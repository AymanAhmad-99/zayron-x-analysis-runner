#!/usr/bin/env python3
"""
cve_worker.py — Fetches latest 24-hour CVEs from the NIST NVD API
and upserts them into the Supabase `cves` table.

Usage:
    python cve_worker.py
    NVD_API_KEY=your_key python cve_worker.py   # higher rate limit

Environment variables:
    NVD_API_KEY      Optional NVD API key (50 requests / 30s vs 5 unauthenticated)
    SUPABASE_URL     Override Supabase project URL
    SUPABASE_KEY     Override Supabase anon/service_role key
"""

import urllib.request
import urllib.error
import urllib.parse
import json
import os
import sys
import time
import logging
from datetime import datetime, timedelta, timezone

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL:
    log.critical("SUPABASE_URL is not set. Export SUPABASE_URL and retry.")
    sys.exit(1)
if not SUPABASE_KEY:
    log.critical("SUPABASE_KEY is not set. Export SUPABASE_KEY and retry.")
    sys.exit(1)
NVD_BASE_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
log = logging.getLogger("cve_worker")


# ---------------------------------------------------------------------------
# NVD API
# ---------------------------------------------------------------------------
def fetch_nvd_cves(start_date: datetime, end_date: datetime,
                   api_key: str | None = None) -> list[dict]:
    """Fetch CVEs published between *start_date* and *end_date* from NVD."""

    def fmt(dt: datetime) -> str:
        return dt.strftime("%Y-%m-%dT%H:%M:%S.000")

    params = {
        "pubStartDate": fmt(start_date),
        "pubEndDate": fmt(end_date),
        "startIndex": 0,
        "resultsPerPage": 100,
    }

    headers = {"User-Agent": "ZAYRON-CVE-Worker/1.0"}
    if api_key:
        headers["apiKey"] = api_key

    all_vulns: list[dict] = []
    total_results = None

    while True:
        url = NVD_BASE_URL + "?" + urllib.parse.urlencode(params)
        log.info("Fetching NVD page (startIndex=%d) …", params["startIndex"])

        req = urllib.request.Request(url, headers=headers)

        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            log.error("NVD API HTTP %s: %s", exc.code, exc.reason)
            if exc.code == 403:
                log.warning("Rate limited — sleeping 60s …")
                time.sleep(60)
                continue
            break
        except Exception as exc:
            log.error("NVD request failed: %s", exc)
            break

        vulns = data.get("vulnerabilities", [])
        total_results = data.get("totalResults", 0)
        all_vulns.extend(vulns)

        log.info("  → got %d vulns (total: %s)", len(vulns), total_results)

        params["startIndex"] += len(vulns)
        if params["startIndex"] >= (total_results or 0):
            break

        # Rate-limit safety
        time.sleep(0.6 if api_key else 6.0)

    # Deduplicate by CVE ID (NVD may return overlapping pages)
    seen = set()
    unique = []
    for v in all_vulns:
        cve_id = v.get("cve", {}).get("id", "")
        if cve_id not in seen:
            seen.add(cve_id)
            unique.append(v)

    return unique


def parse_cve(vuln: dict) -> dict | None:
    """Convert a raw NVD vulnerability object into our cves row schema."""
    cve = vuln.get("cve")
    if not cve:
        return None

    cve_id = cve.get("id", "")
    if not cve_id:
        return None

    # --- Severity & CVSS score ---
    severity = "UNKNOWN"
    cvss_score = 0.0

    # Prefer CVSS 3.1, fall back to 3.0, then 2.0
    for metric_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
        metrics = cve.get("metrics", {}).get(metric_key)
        if metrics and len(metrics) > 0:
            cvss_data = metrics[0].get("cvssData", {})
            cvss_score = float(cvss_data.get("baseScore", 0.0))
            raw_sev = cvss_data.get("baseSeverity", "UNKNOWN").upper()

            # Normalise severity labels
            if raw_sev in ("CRITICAL", "HIGH", "MEDIUM", "LOW"):
                severity = raw_sev.capitalize()
            elif raw_sev in ("NONE", "LOW"):
                severity = "Low"
            elif raw_sev == "MEDIUM":
                severity = "Medium"
            break

    # Map numeric score when string severity missing
    if severity == "UNKNOWN" and cvss_score > 0:
        if cvss_score >= 9.0:
            severity = "Critical"
        elif cvss_score >= 7.0:
            severity = "High"
        elif cvss_score >= 4.0:
            severity = "Medium"
        else:
            severity = "Low"

    # --- Product ---
    product = extract_product(cve)

    # --- Published date ---
    published_raw = cve.get("published", "")
    published_date = published_raw.replace("Z", "+00:00") if published_raw else None

    return {
        "cve_id": cve_id,
        "severity": severity,
        "cvss_score": cvss_score,
        "product": product,
        "published_date": published_date,
    }


def extract_product(cve: dict) -> str:
    """Try to extract a meaningful product name from CVE data."""
    # Strategy 1: configurations → CPE match strings
    try:
        nodes = cve.get("configurations", [])
        for node in nodes:
            for match in node.get("nodes", []):
                for cpe_match in match.get("cpeMatch", []):
                    criteria = cpe_match.get("criteria", "")
                    parts = criteria.split(":")
                    if len(parts) >= 5:
                        vendor = parts[3]
                        prod = parts[4]
                        if prod != "*" and prod != parts[3]:
                            return f"{vendor} {prod}".title()
    except Exception:
        pass

    # Strategy 2: first English description as fallback
    try:
        for desc in cve.get("descriptions", []):
            if desc.get("lang") == "en":
                text = desc.get("value", "")
                # Take first 60 chars, stop at sentence boundary
                return text.split(". ")[0][:80] or "Unknown"
    except Exception:
        pass

    return "Unknown"


# ---------------------------------------------------------------------------
# Supabase
# ---------------------------------------------------------------------------
def upsert_cves(cves: list[dict]) -> int:
    """Upsert the list of CVE rows into Supabase. Returns count inserted."""
    if not cves:
        log.info("No CVEs to upsert.")
        return 0

    # Split into batches of 50 (Supabase request size limit)
    batch_size = 50
    total = 0

    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates",
    }

    for i in range(0, len(cves), batch_size):
        batch = cves[i:i + batch_size]
        url = f"{SUPABASE_URL}/rest/v1/cves?on_conflict=cve_id"

        payload = json.dumps(batch).encode("utf-8")
        req = urllib.request.Request(url, data=payload, headers=headers,
                                     method="POST")

        try:
            with urllib.request.urlopen(req, timeout=15) as resp:
                status = resp.status
                if status in (200, 201, 204):
                    total += len(batch)
                    log.info("Upserted batch %d-%d: %d rows (HTTP %d)",
                             i + 1, min(i + batch_size, len(cves)),
                             len(batch), status)
                else:
                    log.warning("Batch %d-%d returned HTTP %d",
                                i + 1, min(i + batch_size, len(cves)),
                                status)
        except urllib.error.HTTPError as exc:
            body = exc.read().decode("utf-8")[:300]
            log.error("Supabase upsert HTTP %s: %s", exc.code, body)
        except Exception as exc:
            log.error("Supabase upsert error: %s", exc)

        time.sleep(0.3)  # mild throttle

    return total


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------
def main():
    api_key = os.getenv("NVD_API_KEY")

    now = datetime.now(timezone.utc)
    since = now - timedelta(hours=24)

    log.info("Fetching CVEs published between %s and %s …",
             since.isoformat(), now.isoformat())

    vulns = fetch_nvd_cves(since, now, api_key)
    log.info("Received %d total CVE items from NVD.", len(vulns))

    parsed = []
    for v in vulns:
        row = parse_cve(v)
        if row:
            parsed.append(row)

    log.info("Parsed %d valid CVE records.", len(parsed))

    if not parsed:
        log.info("No new CVEs in the last 24 hours.")
        return

    inserted = upsert_cves(parsed)
    log.info("Done — %d CVEs upserted into Supabase.", inserted)


if __name__ == "__main__":
    main()
