#!/usr/bin/env python3
"""
cti_ingestion_engine.py — Enterprise-grade asynchronous Cyber Threat
Intelligence ingestion pipeline for the ZAYRON SECURITY platform.

Architecture
────────────
  FeedFetcher (aiohttp + feedparser)
       │
       ▼
  RawArticle deduplication via url_hash (SHA-256)
       │
       ▼
  LLMAnalyzer  ──►  Structured CTI SITREP
       │               (Executive Summary,
       │                Technical Analysis,
       │                MITRE ATT&CK TTPs,
       │                Actionable Intelligence)
       ▼
  Normalizer ──► Supabase `articles` table upsert
       │
       ▼
  Enterprise Logging & Telemetry

Usage
─────
    export LLM_API_KEY="sk-..."
    python cti_ingestion_engine.py

Environment variables
─────────────────────
    LLM_API_KEY       Required. API key for the LLM provider.
    LLM_BASE_URL      Base URL (default: https://api.openai.com/v1)
    LLM_MODEL         Model name (default: gpt-4o)
    SUPABASE_URL      Supabase project URL (built-in default)
    SUPABASE_KEY      Supabase anon / service_role key (built-in default)
    POLL_INTERVAL     Polling interval in minutes (default: 15)
    CTI_DEBUG         Set to "true" for verbose logging
    MAX_ARTICLES      Max articles to process per cycle (default: 20)
"""

from __future__ import annotations

import asyncio
import hashlib
import json
import logging
import os
import random
import sys
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

import aiohttp
import feedparser

from openai import AsyncOpenAI

# ---------------------------------------------------------------------------
# Configuration — environment variables with sensible defaults
# ---------------------------------------------------------------------------

SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_KEY")

if not SUPABASE_URL:
    log.critical("SUPABASE_URL is not set. Export SUPABASE_URL and retry.")
    sys.exit(1)
if not SUPABASE_KEY:
    log.critical("SUPABASE_KEY is not set. Export SUPABASE_KEY and retry.")
    sys.exit(1)

LLM_API_KEY: str = os.getenv("LLM_API_KEY", "")
LLM_BASE_URL: str = os.getenv("LLM_BASE_URL", "https://api.openai.com/v1")
LLM_MODEL: str = os.getenv("LLM_MODEL", "gpt-4o")

POLL_INTERVAL_MINUTES: int = int(os.getenv("POLL_INTERVAL", "15"))
MAX_ARTICLES_PER_CYCLE: int = int(os.getenv("MAX_ARTICLES", "5"))
MAX_CONTENT_CHARS: int = 16_000  # Truncate raw article text sent to LLM
LLM_TIMEOUT_SEC: int = 60       # Per-LLM-call timeout

# ---------------------------------------------------------------------------
# Rotating User-Agent pool
# ---------------------------------------------------------------------------

USER_AGENTS: list[str] = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:127.0) "
    "Gecko/20100101 Firefox/127.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_5) AppleWebKit/605.1.15 "
    "(KHTML, like Gecko) Version/17.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36",
]

# ---------------------------------------------------------------------------
# Dynamic author pool — 8 realistic CTI analysts, globally distributed
# Implements author rotation to simulate a 24/7 human team.
# ---------------------------------------------------------------------------

CTI_AUTHORS: list[str] = [
    "Marcus Kovac",
    "Dr. Tariq Youssef",
    "Sarah Chen",
    "Elena Voss",
    "David Hughes",
    "Aiko Tanaka",
    "Dmitri Volkov",
    "Omar Al-Fayed",
]


def pick_author() -> str:
    """Return a randomly selected CTI analyst name."""
    return random.choice(CTI_AUTHORS)

# ---------------------------------------------------------------------------
# Feed source definitions
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class FeedSource:
    """Descriptor for a single OSINT RSS feed."""
    name: str
    url: str
    category: str


FEED_SOURCES: list[FeedSource] = [
    FeedSource(
        name="BleepingComputer",
        url="https://www.bleepingcomputer.com/feed/",
        category="Threat Intelligence",
    ),
    FeedSource(
        name="The Hacker News",
        url="https://feeds.feedburner.com/TheHackersNews",
        category="Threat Intelligence",
    ),
    FeedSource(
        name="Dark Reading",
        url="https://www.darkreading.com/rss/all.xml",
        category="Threat Intelligence",
    ),
]

# ---------------------------------------------------------------------------
# Structured-logging setup
# ---------------------------------------------------------------------------

logging.basicConfig(
    level=logging.DEBUG if os.getenv("CTI_DEBUG", "").lower() == "true"
         else logging.INFO,
    format="%(asctime)s - %(levelname)s - [CTI_ENGINE] - %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    stream=sys.stdout,
)
log = logging.getLogger("cti_engine")

# ---------------------------------------------------------------------------
# CTI SITREP schema & LLM prompt
# ---------------------------------------------------------------------------

CTI_SYSTEM_PROMPT: str = """\
You are a Senior Threat Intelligence Analyst at ZAYRON SECURITY, producing \
Massive Threat Briefings — deep-dive intelligence reports for Fortune 500 \
security teams. The raw article below is your source material. Expand it into \
a comprehensive, long-form briefing.

--- MANDATE: MASSIVE THREAT BRIEFING STYLE ---
Write like a seasoned Dark Reading or BleepingComputer journalist — dry, \
authoritative, direct, and deeply technical.
- Each briefing MUST be between 1500–3000 words. Go deep. Go wide.
- Structure the briefing with the following Markdown sections. Every section \
MUST be present:

  ## EXECUTIVE THREAT BRIEF
  — 2–3 paragraphs: what happened, who is affected, why it matters globally. \
  Include estimated impact scope (number of organizations, geographies, \
  sectors affected).

  ## KEY TECHNICAL DETAILS
  — Thorough technical breakdown: vulnerability mechanisms, malware family \
  lineage, exploit chains, attack vectors, CVE IDs with CVSS scores. Include \
  version numbers, file hashes, IP addresses, domain names, registry keys, \
  or any other IoCs extractable from the source.

  ## THREAT ACTOR & TTP ANALYSIS
  — Map the activity to known threat actors/groups. Provide MITRE ATT&CK \
  mappings with precise technique IDs (e.g., T1566.001 — Spearphishing \
  Attachment). Describe the full kill chain from initial access to \
  exfiltration or impact.

  ## DETECTION & DEFENSE STRATEGIES
  — Concrete, actionable detection guidance: Sigma rules, YARA signatures, \
  Splunk/ELK queries, network detection patterns, EDR telemetry queries. \
  Specific IoCs to hunt. No generic advice.

  ## PATCHING & MITIGATION ROADMAP
  — Prioritised remediation steps: which patches first, workarounds if no \
  patch exists, configuration hardening steps, timeline estimates.

  ## INDICATORS OF COMPROMISE (IoC)
  — Structured list of IoCs in a Markdown table:
  | Type | Value | Context |
  |------|-------|---------|
  | SHA256 | abc123... | Malware binary hash |
  | IPv4 | 192.0.2.1 | C2 server |

- NEVER use these phrases: "In conclusion", "It is important to note", \
"It's worth noting", "As a cybersecurity expert", "In today's digital \
landscape", "In the ever-evolving world", "Let's delve into", "This \
underscores the need for", "This highlights the importance of".
- No exclamation marks. No rhetorical questions. Every sentence states a \
fact or gives an assessment.
-- MITRE ATT&CK TTPs must be precise IDs with canonical names (e.g. \
"T1566.001 — Spearphishing Attachment"). Never fabricate TTPs.

Return a **valid JSON object** (no markdown, no code fences):

{
  "title": "Max 120 chars, hard-hitting headline",
  "executive_summary": "2-3 sentences: what happened, who is affected, \
why it matters — stripped of all hedging",
  "content": "## EXECUTIVE THREAT BRIEF\\n\\n... ",
  "mitre_attack_ttps": ["T1566.001 — Spearphishing Attachment"]
}

Rules:
1. If the article has no threat-intelligence value, set "title" to null.
2. Base your analysis strictly on the provided text and your general \
threat-intelligence knowledge of the actors, malware families, and \
vulnerabilities referenced.
3. The `content` field MUST be a complete Markdown document starting with \
`## EXECUTIVE THREAT BRIEF` and containing ALL sections listed above. \
Use proper Markdown: headings (##, ###), bold, tables, code blocks, lists.
4. Return ONLY the JSON — no commentary, no explanation, no sign-off."""

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

JITTER_MIN_SEC: int = 300      # 5 minutes
JITTER_MAX_SEC: int = 14_400   # 4 hours


def jitter_created_at() -> str:
    """Return an ISO-8601 timestamp jittered backward 5 min–4 hr from now.

    This mimics human publishing schedules so bulk-ingested articles
    don't all share the exact same ``created_at`` value.
    """
    offset = random.randint(JITTER_MIN_SEC, JITTER_MAX_SEC)
    jittered = datetime.now(timezone.utc) - timedelta(seconds=offset)
    return jittered.strftime("%Y-%m-%d %H:%M:%S")


def compute_url_hash(url: str) -> str:
    """Deterministic SHA-256 of the canonical article URL for dedup."""
    return hashlib.sha256(url.encode("utf-8")).hexdigest()


def estimate_read_time(text: str) -> int:
    """Estimate reading time in minutes (~200 words / min)."""
    word_count = len(text.split())
    return max(1, round(word_count / 200))


def truncate_content(text: str, max_chars: int = MAX_CONTENT_CHARS) -> str:
    """Truncate text to *max_chars* at the nearest sentence boundary."""
    if len(text) <= max_chars:
        return text
    truncated = text[:max_chars]
    last_period = truncated.rfind(".")
    if last_period > max_chars // 2:
        return text[: last_period + 1]
    return truncated


# ---------------------------------------------------------------------------
# 1. Feed Fetcher (async, aiohttp)
# ---------------------------------------------------------------------------

async def fetch_feed(
    session: aiohttp.ClientSession,
    source: FeedSource,
) -> str | None:
    """Fetch raw RSS/Atom XML from a single *source*.

    Implements exponential backoff (3 retries) with jitter.
    Returns the response body as text, or *None* on total failure.
    """
    headers = {
        "User-Agent": random.choice(USER_AGENTS),
        "Accept": "application/rss+xml, application/xml, text/xml, */*",
    }
    timeout = aiohttp.ClientTimeout(total=30)

    max_retries = 3
    for attempt in range(1, max_retries + 1):
        try:
            async with session.get(
                source.url, headers=headers, timeout=timeout,
            ) as resp:
                resp.raise_for_status()
                text = await resp.text()
                log.info(
                    "Fetched %s — HTTP %d (%.1f KB)",
                    source.name, resp.status, len(text) / 1024,
                )
                return text
        except asyncio.TimeoutError:
            log.warning(
                "Timeout fetching %s (attempt %d/%d)",
                source.name, attempt, max_retries,
            )
        except aiohttp.ClientError as exc:
            log.warning(
                "HTTP error fetching %s (attempt %d/%d): %s",
                source.name, attempt, max_retries, exc,
            )

        if attempt < max_retries:
            sleep_sec = (2 ** attempt) + random.uniform(0, 1)
            log.debug("Backoff %.1fs before retry …", sleep_sec)
            await asyncio.sleep(sleep_sec)

    log.error("Failed to fetch %s after %d attempts.", source.name, max_retries)
    return None


async def fetch_all_feeds(
    session: aiohttp.ClientSession,
) -> list[tuple[FeedSource, str | None]]:
    """Concurrently fetch all configured feeds."""
    tasks = [fetch_feed(session, src) for src in FEED_SOURCES]
    results = await asyncio.gather(*tasks, return_exceptions=False)
    return [(src, text) for src, text in zip(FEED_SOURCES, results)]


# ---------------------------------------------------------------------------
# 2. Feed Parser (feedparser)
# ---------------------------------------------------------------------------

@dataclass
class RawArticle:
    """Normalised representation of a single RSS entry before LLM analysis."""
    source_name: str
    source_category: str
    url: str
    title: str
    description: str
    published: str | None


def parse_feed(
    raw_xml: str,
    source: FeedSource,
) -> list[RawArticle]:
    """Parse RSS/Atom XML into a list of *RawArticle* objects."""
    feed = feedparser.parse(raw_xml)
    entries: list[RawArticle] = []

    for entry in feed.entries:
        url = (entry.get("link") or "").strip()
        if not url:
            continue

        title = (entry.get("title") or "").strip()
        desc = (
            entry.get("summary")
            or entry.get("description")
            or entry.get("content", [{}])[0].get("value")
            or ""
        ).strip()

        if not title and not desc:
            continue

        # Attempt to extract a human-readable date string
        published: str | None = None
        for field_name in ("published", "updated", "created"):
            raw = entry.get(field_name)
            if raw:
                published = str(raw)
                break

        entries.append(RawArticle(
            source_name=source.name,
            source_category=source.category,
            url=url,
            title=title,
            description=desc,
            published=published,
        ))

    log.info("Parsed %d entries from %s", len(entries), source.name)
    return entries


# ---------------------------------------------------------------------------
# 3. LLM Analyst Pipeline
# ---------------------------------------------------------------------------

SITREP_KEYS: frozenset[str] = frozenset({
    "title",
    "executive_summary",
    "content",
    "mitre_attack_ttps",
})


def validate_sitrep(raw: dict[str, Any]) -> dict[str, Any] | None:
    """Validate that a parsed SITREP dict has all required fields."""
    if not isinstance(raw, dict):
        return None
    missing = SITREP_KEYS - raw.keys()
    if missing:
        log.warning("SITREP missing keys: %s", missing)
        return None
    # Ensure mitre_attack_ttps is a list
    if not isinstance(raw.get("mitre_attack_ttps"), list):
        raw["mitre_attack_ttps"] = []
    return raw


async def analyze_article(
    llm: AsyncOpenAI,
    article: RawArticle,
) -> dict[str, Any] | None:
    """Send a single article to the LLM and return a validated SITREP dict.

    Returns *None* if the article has no intelligence value or on failure.
    """
    raw_text = f"Title: {article.title}\n\n{article.description}"
    raw_text = truncate_content(raw_text, MAX_CONTENT_CHARS)

    if not raw_text.strip():
        log.debug("Skipping empty article from %s", article.source_name)
        return None

    t0 = time.monotonic()
    try:
        response = await asyncio.wait_for(
            llm.chat.completions.create(
                model=LLM_MODEL,
                messages=[
                    {"role": "system", "content": CTI_SYSTEM_PROMPT},
                    {"role": "user", "content": raw_text},
                ],
                temperature=0.1,
                max_tokens=8_192,
                response_format={"type": "json_object"},
            ),
            timeout=LLM_TIMEOUT_SEC,
        )
    except asyncio.TimeoutError:
        log.warning("LLM timeout analysing '%s' (%ds)", article.title, LLM_TIMEOUT_SEC)
        return None
    except Exception as exc:
        log.error("LLM error for '%s': %s", article.title, exc)
        return None

    latency = time.monotonic() - t0
    log.info(
        "LLM analysed '%s' — %.1fs (model: %s)",
        article.title[:60], latency, LLM_MODEL,
    )

    # Extract and parse JSON from the response
    content = response.choices[0].message.content or ""
    if not content:
        log.warning("Empty LLM response for '%s'", article.title)
        return None

    try:
        parsed = json.loads(content)
    except json.JSONDecodeError:
        log.warning("LLM returned invalid JSON for '%s'", article.title)
        return None

    # Respect the LLM's decision to skip non-intelligence articles
    if parsed.get("title") is None:
        log.info("LLM flagged '%s' as non-intelligence — skipping", article.title)
        return None

    return validate_sitrep(parsed)


# ---------------------------------------------------------------------------
# 4. Data Normaliser & Supabase Writer
# ---------------------------------------------------------------------------

def build_article_row(
    article: RawArticle,
    sitrep: dict[str, Any],
) -> dict[str, Any]:
    """Map a *RawArticle* + LLM *sitrep* into the Supabase articles schema."""
    full_content = sitrep["content"]

    return {
        "title": sitrep["title"],
        "author": pick_author(),
        "category": article.source_category,
        "content": full_content,
        "excerpt": sitrep["executive_summary"],
        "mitre_attack_ttps": sitrep.get("mitre_attack_ttps", []),
        "read_time": estimate_read_time(full_content),
        "url_hash": compute_url_hash(article.url),
        "created_at": jitter_created_at(),
    }


# ---------------------------------------------------------------------------
# 4b. Existing-hash query to avoid redundant LLM calls
# ---------------------------------------------------------------------------

async def fetch_existing_hashes(
    session: aiohttp.ClientSession,
) -> set[str]:
    """Return the set of url_hash values already present in the articles table."""
    url = f"{SUPABASE_URL}/rest/v1/articles?select=url_hash"
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Accept": "application/json",
    }
    try:
        async with session.get(url, headers=headers) as resp:
            if resp.status != 200:
                log.warning("Failed to fetch existing hashes (HTTP %d)", resp.status)
                return set()
            data = await resp.json()
            return {row["url_hash"] for row in data if row.get("url_hash")}
    except Exception as exc:
        log.error("Error fetching existing hashes: %s", exc)
        return set()


# ---------------------------------------------------------------------------
# 4c. Supabase upsert
# ---------------------------------------------------------------------------

async def upsert_articles(
    rows: list[dict[str, Any]],
) -> int:
    """Upsert article rows into Supabase. Returns count of rows sent."""
    if not rows:
        log.info("No articles to upsert.")
        return 0

    batch_size = 50
    total = 0
    headers = {
        "apikey": SUPABASE_KEY,
        "Authorization": f"Bearer {SUPABASE_KEY}",
        "Content-Type": "application/json",
        "Prefer": "resolution=merge-duplicates",
    }

    async with aiohttp.ClientSession(
        timeout=aiohttp.ClientTimeout(total=30),
    ) as session:
        for i in range(0, len(rows), batch_size):
            batch = rows[i : i + batch_size]
            url = f"{SUPABASE_URL}/rest/v1/articles?on_conflict=url_hash"

            try:
                async with session.post(
                    url, headers=headers, json=batch,
                ) as resp:
                    if resp.status in (200, 201, 204):
                        total += len(batch)
                        log.info(
                            "Upserted batch %d-%d: %d rows (HTTP %d)",
                            i + 1, min(i + batch_size, len(rows)),
                            len(batch), resp.status,
                        )
                    else:
                        body = await resp.text()
                        log.error(
                            "Supabase upsert batch %d-%d failed (HTTP %d): %s",
                            i + 1, min(i + batch_size, len(rows)),
                            resp.status, body[:300],
                        )
            except (aiohttp.ClientError, asyncio.TimeoutError) as exc:
                log.error(
                    "Supabase upsert batch %d-%d error: %s",
                    i + 1, min(i + batch_size, len(rows)), exc,
                )

            await asyncio.sleep(0.3)  # mild throttle

    return total


# ---------------------------------------------------------------------------
# 5. Orchestrator — the main ingestion cycle
# ---------------------------------------------------------------------------

async def ingestion_cycle() -> dict[str, Any]:
    """Execute one complete ingestion cycle.

    Returns a telemetry summary dict.
    """
    start = time.monotonic()
    telemetry: dict[str, Any] = {
        "feeds_fetched": 0,
        "entries_parsed": 0,
        "already_seen": 0,
        "llm_analysed": 0,
        "upserted": 0,
        "errors": 0,
        "llm_total_latency": 0.0,
        "cycle_seconds": 0.0,
    }

    llm = AsyncOpenAI(api_key=LLM_API_KEY, base_url=LLM_BASE_URL)

    async with aiohttp.ClientSession(
        headers={"User-Agent": random.choice(USER_AGENTS)},
        timeout=aiohttp.ClientTimeout(total=30),
    ) as http:

        # ── Step A: Fetch all feeds concurrently ──
        log.info("=== Ingestion cycle start ===")
        feed_results = await fetch_all_feeds(http)
        telemetry["feeds_fetched"] = sum(
            1 for _, text in feed_results if text is not None
        )

        # ── Step B: Parse feeds into articles ──
        all_articles: list[RawArticle] = []
        for source, raw_xml in feed_results:
            if raw_xml is None:
                continue
            try:
                articles = parse_feed(raw_xml, source)
                all_articles.extend(articles)
                telemetry["entries_parsed"] += len(articles)
            except Exception as exc:
                log.error("Parse error for %s: %s", source.name, exc)
                telemetry["errors"] += 1

        if not all_articles:
            log.info("No articles found in this cycle.")
            telemetry["cycle_seconds"] = time.monotonic() - start
            return telemetry

        # ── Step C: Filter out already-ingested articles ──
        existing_hashes = await fetch_existing_hashes(http)
        new_articles = [
            a for a in all_articles
            if compute_url_hash(a.url) not in existing_hashes
        ]
        telemetry["already_seen"] = len(all_articles) - len(new_articles)
        log.info(
            "%d total entries, %d new, %d already in DB",
            len(all_articles), len(new_articles), telemetry["already_seen"],
        )

        if not new_articles:
            log.info("Nothing new to analyse.")
            telemetry["cycle_seconds"] = time.monotonic() - start
            return telemetry

        # ── Step D: LLM analysis (rate-limited concurrency) ──
        new_articles = new_articles[:MAX_ARTICLES_PER_CYCLE]
        analysed: list[tuple[RawArticle, dict[str, Any]]] = []

        semaphore = asyncio.Semaphore(1)  # max 1 concurrent LLM call

        async def analyse_one(article: RawArticle) -> None:
            async with semaphore:
                t0 = time.monotonic()
                sitrep = await analyze_article(llm, article)
                await asyncio.sleep(3)  # rate-limit throttle after each LLM call
                if sitrep is not None:
                    analysed.append((article, sitrep))
                    telemetry["llm_total_latency"] += time.monotonic() - t0
                    telemetry["llm_analysed"] += 1

        tasks = [analyse_one(a) for a in new_articles]
        await asyncio.gather(*tasks, return_exceptions=True)

        if not analysed:
            log.info("No articles survived LLM analysis.")
            telemetry["cycle_seconds"] = time.monotonic() - start
            return telemetry

        # ── Step E: Normalise & upsert ──
        rows = [build_article_row(article, sitrep) for article, sitrep in analysed]
        telemetry["upserted"] = await upsert_articles(rows)

    telemetry["cycle_seconds"] = time.monotonic() - start
    log.info(
        "=== Cycle complete: %d upserted, %d LLM calls, %.1fs total ===",
        telemetry["upserted"], telemetry["llm_analysed"],
        telemetry["cycle_seconds"],
    )
    return telemetry


async def main_loop() -> None:
    """Daemon main loop — runs ingestion cycles on a polling interval."""
    log.info(
        "CTI Ingestion Engine starting — polling every %d min (model: %s)",
        POLL_INTERVAL_MINUTES, LLM_MODEL,
    )
    log.info("LLM endpoint: %s", LLM_BASE_URL)

    if not LLM_API_KEY:
        log.critical("LLM_API_KEY is not set. Export LLM_API_KEY and retry.")
        sys.exit(1)

    cycle_count = 0
    while True:
        cycle_count += 1
        try:
            telemetry = await ingestion_cycle()
        except Exception as exc:
            log.critical("Unhandled exception in cycle %d: %s", cycle_count, exc)
            telemetry = {"errors": 1}

        # Log aggregated telemetry
        if telemetry.get("llm_total_latency", 0) > 0:
            avg_llm = telemetry["llm_total_latency"] / max(telemetry["llm_analysed"], 1)
            log.info(
                "Telemetry cycle=%d | feeds=%d | parsed=%d | new=%d | "
                "llm_ok=%d | avg_llm=%.1fs | upserted=%d | errors=%d | "
                "cycle_time=%.1fs",
                cycle_count,
                telemetry.get("feeds_fetched", 0),
                telemetry.get("entries_parsed", 0),
                telemetry.get("llm_analysed", 0) + telemetry.get("already_seen", 0),
                telemetry.get("llm_analysed", 0),
                avg_llm,
                telemetry.get("upserted", 0),
                telemetry.get("errors", 0),
                telemetry.get("cycle_seconds", 0),
            )

        log.info("Sleeping %d min until next cycle …", POLL_INTERVAL_MINUTES)
        await asyncio.sleep(POLL_INTERVAL_MINUTES * 60)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    """Entry point — supports both single-shot and daemon modes."""
    if "--once" in sys.argv:
        # Single-shot mode for testing / cron integration
        async def _once() -> None:
            if not LLM_API_KEY:
                log.critical("LLM_API_KEY is not set.")
                sys.exit(1)
            await ingestion_cycle()
        asyncio.run(_once())
    else:
        asyncio.run(main_loop())


if __name__ == "__main__":
    main()
