-- ============================================================
-- ZAYRON SECURITY — Zero-Trust RLS Remediation Patch
--
-- Drops all permissive anon/authenticated write policies,
-- enables RLS on all tables, and applies strict read-only
-- access for the anon role.
-- ============================================================

-- ──────────────────────────────────────────────────────────────
-- 1. REVOKE SECURITY DEFINER privilege escalation vector
-- ──────────────────────────────────────────────────────────────
DROP FUNCTION IF EXISTS public.rls_auto_enable() CASCADE;

-- ──────────────────────────────────────────────────────────────
-- 2. ARTICLES
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_articles" ON public.articles;
DROP POLICY IF EXISTS "anon_select_articles" ON public.articles;
DROP POLICY IF EXISTS "Public read access" ON public.articles;
DROP POLICY IF EXISTS "Service role delete" ON public.articles;
DROP POLICY IF EXISTS "Service role insert" ON public.articles;
DROP POLICY IF EXISTS "Service role update" ON public.articles;

-- anon: read-only on published articles
CREATE POLICY "anon_select_published_articles" ON public.articles
  FOR SELECT
  TO anon
  USING (is_published = true);

-- service_role: full access
CREATE POLICY "service_role_all_articles" ON public.articles
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 3. CVES
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.cves ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_cves" ON public.cves;
DROP POLICY IF EXISTS "anon_select_cves" ON public.cves;
DROP POLICY IF EXISTS "anon_update_cves" ON public.cves;
DROP POLICY IF EXISTS "Public read access" ON public.cves;
DROP POLICY IF EXISTS "Service role delete" ON public.cves;
DROP POLICY IF EXISTS "Service role insert" ON public.cves;
DROP POLICY IF EXISTS "Service role update" ON public.cves;

-- anon: read-only
CREATE POLICY "anon_select_cves" ON public.cves
  FOR SELECT
  TO anon
  USING (true);

-- service_role: full access
CREATE POLICY "service_role_all_cves" ON public.cves
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 4. TOOLS
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.tools ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_tools" ON public.tools;
DROP POLICY IF EXISTS "Public read access" ON public.tools;
DROP POLICY IF EXISTS "Service role delete" ON public.tools;
DROP POLICY IF EXISTS "Service role insert" ON public.tools;
DROP POLICY IF EXISTS "Service role update" ON public.tools;

-- anon: read-only
CREATE POLICY "anon_select_tools" ON public.tools
  FOR SELECT
  TO anon
  USING (true);

-- service_role: full access
CREATE POLICY "service_role_all_tools" ON public.tools
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 5. ANALYSTS
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.analysts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_analysts" ON public.analysts;
DROP POLICY IF EXISTS "Public read access" ON public.analysts;
DROP POLICY IF EXISTS "Service role delete" ON public.analysts;
DROP POLICY IF EXISTS "Service role insert" ON public.analysts;
DROP POLICY IF EXISTS "Service role update" ON public.analysts;

-- anon: read-only
CREATE POLICY "anon_select_analysts" ON public.analysts
  FOR SELECT
  TO anon
  USING (true);

-- service_role: full access
CREATE POLICY "service_role_all_analysts" ON public.analysts
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 6. SUBSCRIBERS
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.subscribers ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_subscribers" ON public.subscribers;
DROP POLICY IF EXISTS "anon_select_subscribers" ON public.subscribers;
DROP POLICY IF EXISTS "Public read access" ON public.subscribers;
DROP POLICY IF EXISTS "Service role delete" ON public.subscribers;
DROP POLICY IF EXISTS "Service role insert" ON public.subscribers;
DROP POLICY IF EXISTS "Service role update" ON public.subscribers;

-- anon: insert-only for newsletter signups, no read
CREATE POLICY "anon_insert_subscribers" ON public.subscribers
  FOR INSERT
  TO anon
  WITH CHECK (true);

-- service_role: full access
CREATE POLICY "service_role_all_subscribers" ON public.subscribers
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 7. RAW FEEDS
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.raw_feeds ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_raw_feeds" ON public.raw_feeds;
DROP POLICY IF EXISTS "Public read access" ON public.raw_feeds;
DROP POLICY IF EXISTS "Service role delete" ON public.raw_feeds;
DROP POLICY IF EXISTS "Service role insert" ON public.raw_feeds;
DROP POLICY IF EXISTS "Service role update" ON public.raw_feeds;

-- anon: read-only
CREATE POLICY "anon_select_raw_feeds" ON public.raw_feeds
  FOR SELECT
  TO anon
  USING (true);

-- service_role: full access
CREATE POLICY "service_role_all_raw_feeds" ON public.raw_feeds
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 8. TRENDING
-- ──────────────────────────────────────────────────────────────
ALTER TABLE public.trending ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_trending" ON public.trending;
DROP POLICY IF EXISTS "Public read access" ON public.trending;
DROP POLICY IF EXISTS "Service role delete" ON public.trending;
DROP POLICY IF EXISTS "Service role insert" ON public.trending;
DROP POLICY IF EXISTS "Service role update" ON public.trending;

-- anon: read-only
CREATE POLICY "anon_select_trending" ON public.trending
  FOR SELECT
  TO anon
  USING (true);

-- service_role: full access
CREATE POLICY "service_role_all_trending" ON public.trending
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ──────────────────────────────────────────────────────────────
-- 9. Verify the patch
-- ──────────────────────────────────────────────────────────────
SELECT
  schemaname || '.' || tablename AS table_name,
  policyname,
  permissive,
  roles,
  cmd AS command,
  qual AS using_expression,
  with_check AS check_expression
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;
