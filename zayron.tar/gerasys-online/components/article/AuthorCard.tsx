interface AuthorCardProps {
  name: string;
  title?: string;
  bio?: string;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();
}

export function AuthorCard({ name, title, bio }: AuthorCardProps) {
  return (
    <div className="flex items-start gap-4 bg-[var(--color-cream)] rounded-xl p-5 my-8">
      <div className="w-12 h-12 rounded-full bg-[var(--color-copper)] text-white flex items-center justify-center font-display font-bold shrink-0">
        {getInitials(name)}
      </div>
      <div>
        <h3 className="font-display font-bold text-base text-[var(--color-obsidian)]">
          {name}
        </h3>
        {title && (
          <p className="text-xs text-[var(--color-stone)] font-ui">{title}</p>
        )}
        {bio && (
          <p className="text-sm text-[var(--color-stone)] mt-1.5 font-body leading-relaxed">
            {bio}
          </p>
        )}
      </div>
    </div>
  );
}
