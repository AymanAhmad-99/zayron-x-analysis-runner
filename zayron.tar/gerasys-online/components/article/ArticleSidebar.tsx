import { type Article } from "@/lib/db/schema";
import Link from "next/link";
import { TrendingWidget } from "@/components/homepage/TrendingWidget";

interface ArticleSidebarProps {
  trending: Article[];
  ctaContent?: string;
}

export function ArticleSidebar({ trending }: ArticleSidebarProps) {
  return (
    <aside className="space-y-8">
      {/* Newsletter CTA */}
      <div className="glass-panel !bg-[var(--color-obsidian)]/90 !border-white/10 rounded-xl p-5 text-center">
        <h3 className="font-display font-bold text-white text-lg">
          Intelligence Briefing
        </h3>
        <p className="text-xs text-gray-400 mt-2 font-ui">
          Daily threat intelligence in your inbox.
        </p>
        <Link
          href="/#newsletter"
          className="mt-3 inline-block text-sm font-semibold bg-[var(--color-copper)] text-white px-5 py-2.5 rounded-lg hover:bg-[var(--color-obsidian)] transition-colors font-ui"
        >
          Subscribe Free
        </Link>
      </div>

      {/* Trending */}
      <TrendingWidget articles={trending} />

      {/* TLP Notice */}
      <div className="border border-[var(--color-border)] rounded-xl p-4 text-center">
        <span className="font-mono text-[9px] uppercase tracking-[0.2em] font-bold text-[var(--color-copper)]">
          TLP:AMBER
        </span>
        <p className="text-[10px] text-[var(--color-stone)] mt-1 font-ui">
          Limited distribution intelligence.
        </p>
      </div>
    </aside>
  );
}
