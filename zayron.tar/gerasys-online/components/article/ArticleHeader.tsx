import { type Article } from "@/lib/db/schema";
import { formatDate } from "@/lib/utils/formatDate";
import { CategoryBadge } from "@/components/ui/CategoryBadge";

interface ArticleHeaderProps {
  article: Article;
  overlay?: boolean;
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();
}

export function ArticleHeader({ article, overlay }: ArticleHeaderProps) {
  const textColor = overlay ? "text-white" : "text-[var(--color-obsidian)]";
  const mutedColor = overlay ? "text-gray-300" : "text-[var(--color-stone)]";
  const borderColor = overlay ? "border-white/20" : "border-[var(--color-border)]";

  return (
    <header className={overlay ? "" : "mb-8"}>
      <nav className={`flex items-center gap-2 text-xs ${mutedColor} mb-4 font-ui`}>
        <a href="/" className="hover:text-[var(--color-copper)] transition-colors">
          Home
        </a>
        <span>/</span>
        <a
          href={`/${article.category.toLowerCase().replace(/\s+/g, "-")}`}
          className="hover:text-[var(--color-copper)] transition-colors"
        >
          {article.category}
        </a>
      </nav>

      <div className="flex flex-wrap items-center gap-2 mb-3">
        <CategoryBadge category={article.category} />
        {article.isBreaking && (
          <span className="text-[10px] uppercase font-bold bg-red-100 text-red-700 border border-red-200 px-2.5 py-1 rounded font-ui">
            BREAKING
          </span>
        )}
      </div>

      <h1 className={`font-display text-hero font-bold ${textColor} leading-[1.1] text-balance`}>
        {article.title}
      </h1>

      {article.subtitle && (
        <p className={`text-lg ${mutedColor} mt-3 font-body italic`}>
          {article.subtitle}
        </p>
      )}

      <div className={`flex flex-wrap items-center gap-3 mt-5 pt-5 border-t ${borderColor}`}>
        <div className="w-10 h-10 rounded-full bg-[var(--color-copper)] text-white flex items-center justify-center font-display font-bold text-sm">
          {getInitials(article.author)}
        </div>
        <div>
          <span className={`block text-sm font-semibold ${textColor} font-ui`}>
            {article.author}
          </span>
          <span className={`text-xs ${mutedColor} font-ui`}>
            {formatDate(article.createdAt!)} &middot; {article.readTime} min read
            &middot; {article.views?.toLocaleString()} views
          </span>
        </div>
      </div>
    </header>
  );
}
