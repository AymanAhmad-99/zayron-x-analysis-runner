import { type Article } from "@/lib/db/schema";
import { ArticleCard } from "@/components/ui/ArticleCard";

interface RelatedArticlesProps {
  articles: Article[];
}

export function RelatedArticles({ articles }: RelatedArticlesProps) {
  if (!articles.length) return null;

  return (
    <section className="mt-12 pt-8 border-t border-[var(--color-border)]">
      <h2 className="font-display text-xl font-bold text-[var(--color-obsidian)] mb-6">
        Related Intelligence
      </h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {articles.slice(0, 3).map((article) => (
          <ArticleCard key={article.id} article={article} variant="default" />
        ))}
      </div>
    </section>
  );
}
