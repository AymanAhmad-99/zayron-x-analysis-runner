interface SeverityBadgeProps {
  severity: string;
}

const severityStyles: Record<string, string> = {
  critical: "bg-red-100 text-red-800 border-red-300",
  high: "bg-orange-100 text-orange-800 border-orange-300",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-300",
  low: "bg-green-100 text-green-800 border-green-300",
  none: "bg-gray-100 text-gray-600 border-gray-300",
};

export function SeverityBadge({ severity }: SeverityBadgeProps) {
  const key = severity?.toLowerCase() ?? "none";
  const style = severityStyles[key] ?? severityStyles.none;

  return (
    <span
      className={`text-[10px] uppercase font-bold px-2.5 py-1 rounded border ${style}`}
    >
      {severity ?? "UNKNOWN"}
    </span>
  );
}
