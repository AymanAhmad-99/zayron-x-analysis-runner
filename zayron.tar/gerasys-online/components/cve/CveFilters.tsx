"use client";

import { Search } from "lucide-react";
import { useState, type FormEvent } from "react";

interface CveFiltersProps {
  onSearch: (query: string) => void;
  onSeverityChange: (severity: string) => void;
}

const severities = ["All", "Critical", "High", "Medium", "Low"];

export function CveFilters({ onSearch, onSeverityChange }: CveFiltersProps) {
  const [query, setQuery] = useState("");
  const [activeSeverity, setActiveSeverity] = useState("All");

  function handleSubmit(e: FormEvent) {
    e.preventDefault();
    onSearch(query.trim());
  }

  function handleSeverity(severity: string) {
    setActiveSeverity(severity);
    onSeverityChange(severity === "All" ? "" : severity);
  }

  return (
    <div className="flex flex-col sm:flex-row gap-4 mb-8">
      <form onSubmit={handleSubmit} className="relative flex-1">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search CVEs by ID, product, vendor..."
          className="w-full pl-10 pr-4 py-2.5 text-sm bg-white border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-copper)] font-ui"
        />
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[var(--color-stone)]" />
      </form>
      <div className="flex gap-2 flex-wrap">
        {severities.map((s) => (
          <button
            key={s}
            onClick={() => handleSeverity(s)}
            className={`px-3 py-2 text-xs font-bold uppercase tracking-wider rounded-lg transition-all font-ui ${
              activeSeverity === s
                ? "bg-[var(--color-copper)] text-white"
                : "bg-white border border-[var(--color-border)] text-[var(--color-stone)] hover:border-[var(--color-copper)]"
            }`}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}
