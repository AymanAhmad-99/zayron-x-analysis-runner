import { type CVE } from "@/lib/db/schema";
import { SeverityBadge } from "@/components/cve/SeverityBadge";
import { formatDateShort } from "@/lib/utils/formatDate";

interface CveTableProps {
  cves: CVE[];
}

export function CveTable({ cves }: CveTableProps) {
  if (!cves.length) {
    return (
      <div className="text-center py-12 text-[var(--color-stone)] font-ui">
        No CVEs found.
      </div>
    );
  }

  return (
    <div className="overflow-x-auto border border-[var(--color-border)] rounded-xl">
      <table className="w-full text-sm">
        <thead>
          <tr className="bg-[var(--color-cream)] border-b border-[var(--color-border)]">
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold">
              CVE ID
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold">
              Severity
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold">
              CVSS
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold hidden md:table-cell">
              Product
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold hidden md:table-cell">
              Vendor
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold hidden lg:table-cell">
              Published
            </th>
            <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] font-bold">
              Status
            </th>
          </tr>
        </thead>
        <tbody>
          {cves.map((cve) => (
            <tr
              key={cve.id}
              className="border-b border-[var(--color-border)] last:border-0 hover:bg-[var(--color-copper-light)] transition-colors"
            >
              <td className="py-3 px-4">
                <a
                  href={`/cve/${cve.cveId}`}
                  className="font-mono text-sm text-[var(--color-copper)] hover:text-[var(--color-bronze)] transition-colors font-semibold"
                >
                  {cve.cveId}
                </a>
              </td>
              <td className="py-3 px-4">
                <SeverityBadge severity={cve.severity} />
              </td>
              <td className="py-3 px-4 font-mono text-[var(--color-obsidian)] font-semibold">
                {cve.cvssScore ?? "—"}
              </td>
              <td className="py-3 px-4 text-xs text-[var(--color-obsidian)] hidden md:table-cell font-ui">
                {cve.affectedProduct ?? "—"}
              </td>
              <td className="py-3 px-4 text-xs text-[var(--color-obsidian)] hidden md:table-cell font-ui">
                {cve.vendor ?? "—"}
              </td>
              <td className="py-3 px-4 text-xs text-[var(--color-stone)] hidden lg:table-cell font-ui">
                {cve.publishedDate ? formatDateShort(cve.publishedDate) : "—"}
              </td>
              <td className="py-3 px-4">
                <span
                  className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                    cve.status?.toLowerCase() === "active"
                      ? "bg-red-50 text-red-700"
                      : cve.status?.toLowerCase() === "patched"
                      ? "bg-green-50 text-green-700"
                      : "bg-gray-50 text-gray-600"
                  }`}
                >
                  {cve.status ?? "Unknown"}
                </span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
