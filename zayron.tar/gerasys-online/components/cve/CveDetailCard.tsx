import { type CVE } from "@/lib/db/schema";
import { SeverityBadge } from "@/components/cve/SeverityBadge";
import { formatDate } from "@/lib/utils/formatDate";

interface CveDetailCardProps {
  cve: CVE;
}

export function CveDetailCard({ cve }: CveDetailCardProps) {
  return (
    <article className="card-depth overflow-hidden">
      <div className="p-6 lg:p-8">
        <div className="flex flex-wrap items-start justify-between gap-4 mb-6">
          <div>
            <h1 className="font-mono text-2xl lg:text-3xl font-bold text-[var(--color-obsidian)]">
              {cve.cveId}
            </h1>
            {cve.title && (
              <p className="text-[var(--color-stone)] mt-1 font-ui">{cve.title}</p>
            )}
          </div>
          <SeverityBadge severity={cve.severity} />
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6 mb-6 p-4 bg-[var(--color-cream)] rounded-lg">
          <div>
            <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--color-stone)] font-ui">
              CVSS Score
            </span>
            <p className="font-mono text-xl font-bold text-[var(--color-obsidian)] mt-1">
              {cve.cvssScore ?? "—"}
            </p>
          </div>
          <div>
            <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--color-stone)] font-ui">
              Status
            </span>
            <p className="font-mono text-sm font-semibold text-[var(--color-obsidian)] mt-1">
              {cve.status ?? "Unknown"}
            </p>
          </div>
          {cve.vendor && (
            <div>
              <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--color-stone)] font-ui">
                Vendor
              </span>
              <p className="font-mono text-sm font-semibold text-[var(--color-obsidian)] mt-1">
                {cve.vendor}
              </p>
            </div>
          )}
          <div>
            <span className="text-[10px] uppercase tracking-wider font-bold text-[var(--color-stone)] font-ui">
              Published
            </span>
            <p className="font-mono text-sm font-semibold text-[var(--color-obsidian)] mt-1">
              {cve.publishedDate ? formatDate(cve.publishedDate) : "—"}
            </p>
          </div>
        </div>

        {cve.description && (
          <div>
            <h2 className="font-display text-lg font-bold text-[var(--color-obsidian)] mb-3">
              Description
            </h2>
            <p className="text-sm text-[var(--color-obsidian)] leading-relaxed font-body">
              {cve.description}
            </p>
          </div>
        )}

        {cve.affectedProduct && (
          <div className="mt-6">
            <h2 className="font-display text-lg font-bold text-[var(--color-obsidian)] mb-3">
              Affected Product
            </h2>
            <p className="text-sm text-[var(--color-obsidian)] font-mono bg-[var(--color-cream)] px-3 py-2 rounded">
              {cve.affectedProduct}
            </p>
          </div>
        )}

        {cve.cvssVector && (
          <div className="mt-6">
            <h2 className="font-display text-lg font-bold text-[var(--color-obsidian)] mb-3">
              CVSS Vector
            </h2>
            <code className="text-xs bg-[var(--color-obsidian)] text-[var(--color-cream)] px-3 py-2 rounded block overflow-x-auto font-mono">
              {cve.cvssVector}
            </code>
          </div>
        )}
      </div>
    </article>
  );
}
