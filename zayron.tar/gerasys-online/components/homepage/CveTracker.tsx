import { type CVE } from "@/lib/db/schema";
import { formatDateShort } from "@/lib/utils/formatDate";

interface CveTrackerProps {
  cves: CVE[];
}

const severityColors: Record<string, string> = {
  critical: "bg-red-100 text-red-800 border-red-300",
  high: "bg-orange-100 text-orange-800 border-orange-300",
  medium: "bg-yellow-100 text-yellow-800 border-yellow-300",
  low: "bg-green-100 text-green-800 border-green-300",
};

export function CveTracker({ cves }: CveTrackerProps) {
  if (!cves.length) return null;

  return (
    <section className="bg-[var(--color-obsidian)] py-12">
      <div className="max-w-7xl mx-auto px-4">
        <div className="mb-6">
          <h2 className="font-mono text-[10px] uppercase tracking-[0.2em] font-bold text-[var(--color-copper)]">
            CVE TRACKER
          </h2>
          <h3 className="font-display text-2xl font-bold text-white mt-1">
            Vulnerability Database
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-[var(--color-copper)]/30">
                <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)]">
                  CVE ID
                </th>
                <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)]">
                  Severity
                </th>
                <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)]">
                  CVSS
                </th>
                <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] hidden md:table-cell">
                  Product
                </th>
                <th className="text-left py-3 px-4 font-mono text-[10px] uppercase tracking-wider text-[var(--color-copper)] hidden lg:table-cell">
                  Published
                </th>
              </tr>
            </thead>
            <tbody>
              {cves.slice(0, 10).map((cve) => (
                <tr
                  key={cve.id}
                  className="border-b border-white/5 hover:bg-white/5 transition-colors"
                >
                  <td className="py-3 px-4">
                    <a
                      href={`/cve/${cve.cveId}`}
                      className="font-mono text-sm text-[var(--color-gold)] hover:text-[var(--color-copper)] transition-colors"
                    >
                      {cve.cveId}
                    </a>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded border ${
                        severityColors[cve.severity?.toLowerCase() ?? ""] ??
                        "bg-gray-100 text-gray-800 border-gray-300"
                      }`}
                    >
                      {cve.severity}
                    </span>
                  </td>
                  <td className="py-3 px-4 font-mono text-white">
                    {cve.cvssScore ?? "—"}
                  </td>
                  <td className="py-3 px-4 text-gray-300 text-xs hidden md:table-cell">
                    {cve.affectedProduct ?? cve.vendor ?? "—"}
                  </td>
                  <td className="py-3 px-4 text-gray-400 text-xs hidden lg:table-cell font-ui">
                    {cve.publishedDate ? formatDateShort(cve.publishedDate) : "—"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
