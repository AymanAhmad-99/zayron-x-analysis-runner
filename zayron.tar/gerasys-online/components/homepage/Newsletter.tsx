"use client";

import { Button } from "@/components/ui/Button";
import { useState, type FormEvent } from "react";

export function Newsletter() {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  async function handleSubmit(e: FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;

    setStatus("loading");
    try {
      const res = await fetch("/api/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatus("success");
        setMessage("Subscribed successfully. Intelligence briefings incoming.");
        setEmail("");
      } else {
        setStatus("error");
        setMessage(data.error ?? "Subscription failed.");
      }
    } catch {
      setStatus("error");
      setMessage("Network error. Please try again.");
    }
  }

  return (
    <section className="bg-[var(--color-obsidian)] py-16" id="newsletter">
      <div className="max-w-7xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-center">
          <div>
            <h2 className="font-mono text-[10px] uppercase tracking-[0.2em] font-bold text-[var(--color-copper)]">
              Stay Ahead
            </h2>
            <h3 className="font-display text-3xl font-bold text-white mt-2 leading-tight">
              Intelligence Briefings,
              <br />
              <span className="text-[var(--color-copper)]">Direct to Inbox</span>
            </h3>
            <p className="text-sm text-gray-400 mt-3 font-ui max-w-md">
              Get the latest threat intelligence, CVE alerts, and APT analysis delivered
              every morning. No noise. Just actionable intelligence.
            </p>
          </div>
          <div className="bg-[var(--color-charcoal)] rounded-xl p-6">
            {status === "success" ? (
              <p className="text-[var(--color-gold)] font-semibold text-center font-ui">
                {message}
              </p>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-3">
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email address"
                  required
                  className="w-full px-4 py-3 text-sm bg-[var(--color-warm-white)] border border-[var(--color-border)] rounded-lg focus:outline-none focus:ring-2 focus:ring-[var(--color-copper)] font-ui"
                />
                <Button
                  type="submit"
                  variant="primary"
                  className="w-full"
                  disabled={status === "loading"}
                >
                  {status === "loading" ? "Subscribing..." : "Subscribe Free"}
                </Button>
                {status === "error" && (
                  <p className="text-red-400 text-xs text-center font-ui">{message}</p>
                )}
                <p className="text-[10px] text-gray-500 text-center font-ui">
                  No spam. Unsubscribe anytime.
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
