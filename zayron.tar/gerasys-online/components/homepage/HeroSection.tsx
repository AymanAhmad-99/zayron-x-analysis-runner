import { type Article } from "@/lib/db/schema";
import Link from "next/link";
import { CategoryBadge } from "@/components/ui/CategoryBadge";
import { formatDate } from "@/lib/utils/formatDate";
import { getArticleImage } from "@/lib/utils/fallbackImages";

interface HeroSectionProps {
  primary: Article | null;
  secondary: Article[];
}

export function HeroSection({ primary, secondary }: HeroSectionProps) {
  return (
    <section className="max-w-7xl mx-auto px-4 py-8">
      <div className="grid grid-cols-1 lg:grid-cols-[2fr_1fr] gap-6">
        {primary && (
          <Link
            href={`/article/${primary.slug}`}
            className="group relative bg-[#0D0D0D] rounded-xl overflow-hidden min-h-[400px] lg:min-h-[500px]"
          >
            <img
              src={getArticleImage(primary)}
              alt={primary.title}
              className="absolute inset-0 w-full h-full object-cover opacity-70 group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/60 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
              <CategoryBadge category={primary.category} className="mb-3" />
              <h1 className="font-display text-hero font-bold text-white leading-[1.1] text-balance">
                {primary.title}
              </h1>
              <p className="text-sm text-gray-400 mt-3 line-clamp-2 font-ui max-w-2xl">
                {primary.excerpt ?? primary.content.substring(0, 240)}
              </p>
              <div className="flex items-center gap-3 mt-4 text-xs text-gray-500 font-ui">
                <span className="text-[#B87333] font-semibold">{primary.author}</span>
                <span>·</span>
                <span>{formatDate(primary.createdAt!)}</span>
                <span>·</span>
                <span>{primary.readTime} min read</span>
              </div>
            </div>
          </Link>
        )}

        <aside className="space-y-4">
          {secondary.slice(0, 3).map((article) => (
            <Link
              key={article.id}
              href={`/article/${article.slug}`}
              className="flex gap-4 group items-start bg-[#1a1a1a] rounded-lg p-4 border border-transparent hover:border-[#B87333] transition-all duration-300"
            >
              <img
                src={getArticleImage(article)}
                alt=""
                className="w-20 h-16 rounded object-cover shrink-0"
                loading="lazy"
              />
              <div className="min-w-0">
                <CategoryBadge category={article.category} className="mb-1.5" />
                <h3 className="text-sm font-semibold text-gray-100 line-clamp-2 group-hover:text-[#B87333] transition-colors leading-snug font-display">
                  {article.title}
                </h3>
                <span className="text-xs text-gray-500 mt-1 block font-ui">
                  {article.author}
                </span>
              </div>
            </Link>
          ))}
        </aside>
      </div>
    </section>
  );
}
