import { type Analyst } from "@/lib/db/schema";

interface AnalystTeamProps {
  analysts: Analyst[];
}

function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .substring(0, 2)
    .toUpperCase();
}

export function AnalystTeam({ analysts }: AnalystTeamProps) {
  if (!analysts.length) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-8">
        <h2 className="section-subheading">Our Team</h2>
        <h3 className="section-heading mt-1">Threat Intelligence Analysts</h3>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {analysts.slice(0, 4).map((analyst) => (
          <div
            key={analyst.id}
            className="bg-white border border-[var(--color-border)] rounded-xl p-5 text-center"
          >
            <div className="w-16 h-16 rounded-full bg-[var(--color-copper)] text-white flex items-center justify-center mx-auto mb-3 font-display font-bold text-lg">
              {getInitials(analyst.name)}
            </div>
            <h3 className="font-display font-bold text-base text-[var(--color-obsidian)]">
              {analyst.name}
            </h3>
            <p className="text-xs text-[var(--color-stone)] font-ui mt-0.5">
              {analyst.title}
            </p>
            <p className="text-xs text-[var(--color-stone)] mt-2 line-clamp-2 font-ui">
              {analyst.bio}
            </p>
            {analyst.specializations && analyst.specializations.length > 0 && (
              <div className="flex flex-wrap justify-center gap-1.5 mt-3">
                {analyst.specializations.slice(0, 3).map((spec) => (
                  <span
                    key={spec}
                    className="text-[9px] uppercase tracking-wider font-bold px-2 py-0.5 rounded bg-[var(--color-copper-light)] text-[var(--color-copper)] font-ui"
                  >
                    {spec}
                  </span>
                ))}
              </div>
            )}
          </div>
        ))}
      </div>
    </section>
  );
}
