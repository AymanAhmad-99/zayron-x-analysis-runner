import Link from "next/link";

interface CategoryItem {
  category: string;
  count: number;
}

interface CategoryShowcaseProps {
  categories: CategoryItem[];
}

const categoryIcons: Record<string, string> = {
  vulnerability: "🛡️",
  exploit: "⚡",
  ransomware: "💰",
  nationstate: "🏴",
  ai: "🤖",
  tool: "🔧",
  default: "📰",
};

export function CategoryShowcase({ categories }: CategoryShowcaseProps) {
  if (!categories.length) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-8">
        <h2 className="section-subheading">Browse by Category</h2>
        <h3 className="section-heading mt-1">Intelligence Domains</h3>
      </div>
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        {categories.map((cat) => {
          const key = cat.category.toLowerCase().replace(/\s+/g, "");
          const icon = Object.entries(categoryIcons).find(([k]) =>
            key.includes(k)
          )?.[1] ?? categoryIcons.default;

          return (
            <Link
              key={cat.category}
              href={`/${cat.category.toLowerCase().replace(/\s+/g, "-")}`}
              className="group bg-white border border-[var(--color-border)] rounded-xl p-5 text-center hover:shadow-lg hover:-translate-y-0.5 transition-all duration-200"
            >
              <span className="text-2xl block mb-2">{icon}</span>
              <h3 className="font-display font-semibold text-sm text-[var(--color-obsidian)] group-hover:text-[var(--color-copper)] transition-colors">
                {cat.category}
              </h3>
              <span className="text-xs text-[var(--color-stone)] font-ui mt-1 block">
                {cat.count} {cat.count === 1 ? "report" : "reports"}
              </span>
            </Link>
          );
        })}
      </div>
    </section>
  );
}
