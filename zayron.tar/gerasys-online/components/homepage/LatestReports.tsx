import { type Article } from "@/lib/db/schema";
import Link from "next/link";
import { timeAgo } from "@/lib/utils/formatDate";
import { CategoryBadge } from "@/components/ui/CategoryBadge";

interface LatestReportsProps {
  articles: Article[];
}

export function LatestReports({ articles }: LatestReportsProps) {
  if (!articles.length) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-8">
        <h2 className="section-subheading">Latest Intelligence</h2>
        <h3 className="section-heading mt-1">Recent Reports</h3>
      </div>
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        <ul className="space-y-0">
          {articles.slice(0, 5).map((article, i) => (
            <li key={article.id}>
              <Link
                href={`/article/${article.slug}`}
                className="flex items-start gap-4 py-4 group border-b border-[var(--color-border)] last:border-0"
              >
                <span className="text-2xl font-bold text-[var(--color-copper)] font-display tabular-nums w-8 shrink-0">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <div>
                  <CategoryBadge category={article.category} className="mb-1.5" />
                  <h3 className="text-base font-semibold text-[var(--color-obsidian)] group-hover:text-[var(--color-copper)] transition-colors line-clamp-2 font-display">
                    {article.title}
                  </h3>
                  <span className="text-xs text-[var(--color-stone)] mt-1 block font-ui">
                    {timeAgo(article.createdAt!)}
                  </span>
                </div>
              </Link>
            </li>
          ))}
        </ul>

        {/* Trending / second column */}
        <div className="bg-[var(--color-cream)] rounded-xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-[var(--color-copper)] text-lg">&#x26A1;</span>
            <h3 className="font-display font-bold text-lg text-[var(--color-obsidian)]">
              Trending Now
            </h3>
          </div>
          <ul className="space-y-3">
            {articles.slice(0, 5).map((article, i) => (
              <li key={article.id}>
                <Link
                  href={`/article/${article.slug}`}
                  className="flex items-center gap-3 group"
                >
                  <span className="text-[10px] font-bold text-[var(--color-stone)] font-mono w-5">
                    {String(i + 1).padStart(2, "0")}
                  </span>
                  <span className="text-sm text-[var(--color-obsidian)] group-hover:text-[var(--color-copper)] transition-colors line-clamp-1 font-medium">
                    {article.title}
                  </span>
                  <span className="text-xs text-[var(--color-copper)] ml-auto shrink-0 font-mono">
                    {article.views ?? 0}
                  </span>
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </section>
  );
}
