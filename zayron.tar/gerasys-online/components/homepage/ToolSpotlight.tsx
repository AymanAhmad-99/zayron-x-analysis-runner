import { type Tool } from "@/lib/db/schema";
import Link from "next/link";
import { Star, ExternalLink, GitFork } from "lucide-react";

interface ToolSpotlightProps {
  tools: Tool[];
}

export function ToolSpotlight({ tools }: ToolSpotlightProps) {
  if (!tools.length) return null;

  return (
    <section className="max-w-7xl mx-auto px-4 py-12">
      <div className="mb-8">
        <h2 className="section-subheading">Tool Spotlight</h2>
        <h3 className="section-heading mt-1">Community Favorites</h3>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {tools.slice(0, 4).map((tool) => (
          <div
            key={tool.id}
            className="bg-white border border-[var(--color-border)] rounded-xl p-5 hover:shadow-lg transition-shadow"
          >
            <div className="flex items-start justify-between mb-3">
              <span className="text-[10px] uppercase font-bold text-[var(--color-copper)] tracking-wider font-ui">
                {tool.category}
              </span>
              {tool.rating && (
                <span className="flex items-center gap-1 text-xs text-[var(--color-gold)] font-medium">
                  <Star size={12} fill="currentColor" />
                  {tool.rating}
                </span>
              )}
            </div>
            <h3 className="font-display font-bold text-base text-[var(--color-obsidian)] mb-1">
              {tool.name}
            </h3>
            <p className="text-xs text-[var(--color-stone)] line-clamp-2 font-ui mb-4">
              {tool.description}
            </p>
            <div className="flex items-center justify-between">
              <span className="flex items-center gap-1 text-xs text-[var(--color-stone)] font-mono">
                <GitFork size={12} />
                {tool.stars ?? 0}
              </span>
              {tool.githubUrl && (
                <Link
                  href={tool.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-xs text-[var(--color-copper)] hover:underline flex items-center gap-1 font-ui"
                >
                  GitHub <ExternalLink size={10} />
                </Link>
              )}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
