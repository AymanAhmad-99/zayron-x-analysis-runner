import { type Article } from "@/lib/db/schema";
import Link from "next/link";

interface TrendingWidgetProps {
  articles: Article[];
}

export function TrendingWidget({ articles }: TrendingWidgetProps) {
  if (!articles.length) return null;

  return (
    <div className="bg-[var(--color-cream)] rounded-xl p-5">
      <div className="flex items-center gap-2 mb-4">
        <span className="text-lg">&#x26A1;</span>
        <h3 className="font-display font-bold text-[var(--color-obsidian)] text-base">
          Trending
        </h3>
      </div>
      <ul className="space-y-3">
        {articles.slice(0, 5).map((article, i) => (
          <li key={article.id}>
            <Link
              href={`/article/${article.slug}`}
              className="flex items-center gap-3 group"
            >
              <span className="text-[10px] font-bold text-[var(--color-stone)] font-mono w-5">
                {String(i + 1).padStart(2, "0")}
              </span>
              <div className="min-w-0 flex-1">
                <span className="text-sm text-[var(--color-obsidian)] group-hover:text-[var(--color-copper)] transition-colors line-clamp-1 font-medium block">
                  {article.title}
                </span>
                <span className="text-xs text-[var(--color-stone)] font-ui">
                  {article.views?.toLocaleString()} views
                </span>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
