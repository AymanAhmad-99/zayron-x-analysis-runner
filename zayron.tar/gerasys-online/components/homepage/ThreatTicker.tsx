import { type CVE } from "@/lib/db/schema";

interface ThreatTickerProps {
  cves: CVE[];
}

export function ThreatTicker({ cves }: ThreatTickerProps) {
  if (!cves.length) return null;

  const doubled = [...cves, ...cves];

  return (
    <section className="bg-[var(--color-obsidian)] border-y border-[var(--color-copper)] overflow-hidden h-10">
      <div className="flex h-full">
        <div className="shrink-0 bg-[var(--color-copper)] px-4 flex items-center">
          <span className="text-[10px] uppercase tracking-[0.15em] font-bold text-white font-mono">
            THREAT MONITOR
          </span>
        </div>
        <div className="overflow-hidden flex-1 relative">
          <div className="animate-ticker flex gap-16 whitespace-nowrap absolute h-full items-center">
            {doubled.map((cve, i) => (
              <span
                key={`${cve.cveId}-${i}`}
                className="text-xs text-[var(--color-cream)] font-mono"
              >
                <span className="text-[var(--color-copper)] font-bold">{cve.cveId}</span>
                {" — "}
                {cve.affectedProduct ?? cve.vendor ?? "Unknown"}
                <span className="text-[var(--color-gold)] ml-2">
                  | CVSS {cve.cvssScore}
                </span>
              </span>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
