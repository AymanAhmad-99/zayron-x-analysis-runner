"use client";

import Link from "next/link";
import { useState } from "react";
import { SearchBar } from "@/components/ui/SearchBar";
import { Menu, X, ChevronDown } from "lucide-react";

const navLinks = [
  { label: "Intelligence", href: "/intelligence" },
  { label: "Vulnerabilities", href: "/vulnerabilities" },
  { label: "Ransomware", href: "/ransomware" },
  { label: "Nation State", href: "/nation-state" },
  { label: "Tools", href: "/tools" },
  { label: "CVEs", href: "/cve" },
  { label: "Analysts", href: "/analysts" },
];

export function Header() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [megaOpen, setMegaOpen] = useState(false);

  return (
    <header className="sticky top-0 z-50 glass-panel border-b border-[var(--color-border)]">
      {/* Top bar */}
      <div className="bg-[var(--color-obsidian)] text-white text-[10px] font-mono">
        <div className="max-w-7xl mx-auto px-4 h-8 flex items-center justify-between">
          <span className="uppercase tracking-[0.15em] font-bold text-[var(--color-copper)]">
            ZAYRON SECURITY
          </span>
          <span className="text-[var(--color-stone)]">
            CYBER THREAT INTELLIGENCE PLATFORM
          </span>
        </div>
      </div>

      {/* Main nav */}
      <div className="max-w-7xl mx-auto px-4 h-14 flex items-center justify-between">
        <Link href="/" className="font-display text-xl font-bold text-[var(--color-obsidian)] tracking-tight">
          ZAYRON<span className="text-[var(--color-copper)]">.</span>
        </Link>

        {/* Desktop nav */}
        <nav className="hidden lg:flex items-center gap-1">
          {navLinks.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="px-3 py-2 text-sm font-medium text-[var(--color-stone)] hover:text-[var(--color-copper)] transition-colors rounded-md hover:bg-[var(--color-cream)] font-ui"
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <SearchBar className="hidden md:block w-48 lg:w-56" />
          <button
            className="lg:hidden p-2 text-[var(--color-obsidian)]"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Toggle menu"
          >
            {mobileOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {/* Mobile nav */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-[var(--color-border)] bg-[var(--color-warm-white)] animate-slide-down">
          <nav className="px-4 py-3 space-y-1">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="block px-3 py-2.5 text-sm font-medium text-[var(--color-stone)] hover:text-[var(--color-copper)] hover:bg-[var(--color-cream)] rounded-md transition-colors font-ui"
                onClick={() => setMobileOpen(false)}
              >
                {link.label}
              </Link>
            ))}
            <div className="pt-2">
              <SearchBar />
            </div>
          </nav>
        </div>
      )}
    </header>
  );
}
