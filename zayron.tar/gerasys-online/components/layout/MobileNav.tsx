"use client";

import { X } from "lucide-react";
import Link from "next/link";

interface MobileNavProps {
  isOpen: boolean;
  onClose: () => void;
}

const links = [
  { label: "Intelligence", href: "/intelligence" },
  { label: "Vulnerabilities", href: "/vulnerabilities" },
  { label: "Ransomware", href: "/ransomware" },
  { label: "Nation State", href: "/nation-state" },
  { label: "Tools", href: "/tools" },
  { label: "CVEs", href: "/cve" },
  { label: "Analysts", href: "/analysts" },
  { label: "About", href: "/about" },
  { label: "Contact", href: "/contact" },
];

export function MobileNav({ isOpen, onClose }: MobileNavProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="absolute top-0 right-0 w-72 h-full bg-[var(--color-warm-white)] shadow-xl animate-slide-down">
        <div className="flex items-center justify-between p-4 border-b border-[var(--color-border)]">
          <span className="font-display font-bold text-[var(--color-obsidian)]">Menu</span>
          <button onClick={onClose} aria-label="Close menu">
            <X size={20} />
          </button>
        </div>
        <nav className="p-4 space-y-1">
          {links.map((link) => (
            <Link
              key={link.href}
              href={link.href}
              className="block px-3 py-2.5 text-sm font-medium text-[var(--color-stone)] hover:text-[var(--color-copper)] hover:bg-[var(--color-cream)] rounded-md transition-colors font-ui"
              onClick={onClose}
            >
              {link.label}
            </Link>
          ))}
        </nav>
      </div>
    </div>
  );
}
