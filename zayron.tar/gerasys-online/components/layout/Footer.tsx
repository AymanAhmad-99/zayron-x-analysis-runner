import Link from "next/link";
import { CopperDivider } from "@/components/ui/CopperDivider";

const footerSections = [
  {
    title: "Intelligence",
    links: [
      { label: "Latest Reports", href: "/latest" },
      { label: "Vulnerabilities", href: "/vulnerabilities" },
      { label: "Ransomware", href: "/ransomware" },
      { label: "Nation State", href: "/nation-state" },
      { label: "AI Security", href: "/ai-security" },
    ],
  },
  {
    title: "Resources",
    links: [
      { label: "CVE Tracker", href: "/cve" },
      { label: "Tools Directory", href: "/tools" },
      { label: "Analyst Team", href: "/analysts" },
      { label: "API Access", href: "/api-docs" },
      { label: "Newsletter", href: "#newsletter" },
    ],
  },
  {
    title: "Company",
    links: [
      { label: "About", href: "/about" },
      { label: "Contact", href: "/contact" },
      { label: "Privacy Policy", href: "/privacy" },
      { label: "Terms of Service", href: "/terms" },
    ],
  },
  {
    title: "Connect",
    links: [
      { label: "Twitter / X", href: "https://x.com/zayronsec" },
      { label: "LinkedIn", href: "https://linkedin.com/company/zayron-security" },
      { label: "GitHub", href: "https://github.com/zayronsec" },
      { label: "RSS Feed", href: "/rss.xml" },
    ],
  },
];

export function Footer() {
  return (
    <footer className="bg-[var(--color-obsidian)] text-white mt-16">
      <div className="max-w-7xl mx-auto px-4 py-16">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {footerSections.map((section) => (
            <div key={section.title}>
              <h4 className="text-[10px] uppercase tracking-[0.15em] font-bold text-[var(--color-copper)] mb-4 font-ui">
                {section.title}
              </h4>
              <ul className="space-y-2.5">
                {section.links.map((link) => (
                  <li key={link.label}>
                    <Link
                      href={link.href}
                      className="text-sm text-[var(--color-stone)] hover:text-[var(--color-copper)] transition-colors font-ui"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <CopperDivider className="my-12" />

        <div className="flex flex-col md:flex-row justify-between items-center gap-4">
          <div>
            <Link href="/" className="font-display text-lg font-bold tracking-tight">
              ZAYRON<span className="text-[var(--color-copper)]">.</span>
            </Link>
            <p className="text-xs text-[var(--color-stone)] mt-1 font-ui">
              Premium Cyber Threat Intelligence Platform
            </p>
          </div>
          <div className="text-center md:text-right">
            <p className="text-[10px] uppercase tracking-[0.2em] text-[var(--color-copper)] font-bold font-mono">
              TLP:AMBER — Limited Distribution
            </p>
            <p className="text-xs text-[var(--color-stone)] mt-1 font-ui">
              &copy; {new Date().getFullYear()} ZAYRON SECURITY. All intelligence gathered from open sources.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
