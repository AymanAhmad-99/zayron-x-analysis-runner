import { type ButtonHTMLAttributes } from "react";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
}

export function Button({
  variant = "primary",
  size = "md",
  className = "",
  children,
  ...props
}: ButtonProps) {
  const base =
    "inline-flex items-center justify-center font-semibold font-ui rounded-lg transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-[var(--color-copper)] focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed";

  const variants = {
    primary:
      "bg-[var(--color-copper)] text-white hover:bg-[var(--color-obsidian)]",
    secondary:
      "bg-[var(--color-obsidian)] text-white hover:bg-[var(--color-espresso)]",
    outline:
      "border-2 border-[var(--color-copper)] text-[var(--color-copper)] hover:bg-[var(--color-copper)] hover:text-white",
    ghost: "text-[var(--color-stone)] hover:text-[var(--color-copper)] hover:bg-[var(--color-copper-light)]",
  };

  const sizes = {
    sm: "px-3 py-1.5 text-xs",
    md: "px-5 py-2.5 text-sm",
    lg: "px-7 py-3 text-base",
  };

  return (
    <button
      className={`${base} ${variants[variant]} ${sizes[size]} ${className}`}
      {...props}
    >
      {children}
    </button>
  );
}
