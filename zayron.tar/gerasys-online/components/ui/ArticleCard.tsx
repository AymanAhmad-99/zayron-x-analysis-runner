import { type Article } from "@/lib/db/schema";
import Link from "next/link";
import { formatDate } from "@/lib/utils/formatDate";
import { CategoryBadge } from "@/components/ui/CategoryBadge";
import { getArticleImage } from "@/lib/utils/fallbackImages";

interface ArticleCardProps {
  article: Article;
  variant?: "default" | "hero";
}

export function ArticleCard({ article, variant = "default" }: ArticleCardProps) {
  if (variant === "hero") {
    return (
      <Link
        href={`/article/${article.slug}`}
        className="group relative w-full h-[500px] overflow-hidden rounded-xl"
      >
        <img
          src={getArticleImage(article)}
          alt={article.title}
          className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[#0D0D0D] via-[#0D0D0D]/50 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <CategoryBadge category={article.category} className="mb-3" />
          <h1 className="font-display text-4xl lg:text-5xl font-bold text-white leading-[1.1] text-balance">
            {article.title}
          </h1>
          <p className="text-gray-400 mt-3 line-clamp-2 font-ui max-w-2xl text-sm">
            {article.excerpt ?? article.content.substring(0, 240)}
          </p>
          <div className="flex items-center gap-3 mt-4 text-xs text-gray-500 font-ui">
            <span className="text-[#B87333] font-semibold">{article.author}</span>
            <span>·</span>
            <span>{formatDate(article.createdAt!)}</span>
            <span>·</span>
            <span>{article.readTime} min read</span>
          </div>
        </div>
      </Link>
    );
  }

  return (
    <Link
      href={`/article/${article.slug}`}
      className="group flex flex-col bg-[#1a1a1a] rounded-lg overflow-hidden border border-transparent hover:border-[#B87333] transition-all duration-300"
    >
      <div className="h-48 w-full overflow-hidden">
        <img
          src={getArticleImage(article)}
          alt={article.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
          loading="lazy"
        />
      </div>
      <div className="flex flex-col flex-1 p-5">
        <CategoryBadge category={article.category} className="mb-2" />
        <h3 className="font-display text-lg font-bold text-gray-100 line-clamp-2 group-hover:text-[#B87333] transition-colors">
          {article.title}
        </h3>
        <p className="text-sm text-gray-400 mt-2 line-clamp-2 font-ui flex-1">
          {article.excerpt ?? article.content.substring(0, 120) + "..."}
        </p>
        <div className="flex items-center gap-2 mt-4 text-xs text-gray-500 font-ui pt-3 border-t border-white/5">
          <span className="text-[#B87333] font-semibold">{article.author}</span>
          <span>·</span>
          <span>{formatDate(article.createdAt!)}</span>
          <span>·</span>
          <span>{article.readTime} min</span>
        </div>
      </div>
    </Link>
  );
}
