interface CategoryBadgeProps {
  category: string;
  className?: string;
}

const categoryColors: Record<string, string> = {
  vulnerability: "bg-red-900/30 text-red-300 border-red-800",
  exploit: "bg-orange-900/30 text-orange-300 border-orange-800",
  ransomware: "bg-rose-900/30 text-rose-300 border-rose-800",
  malware: "bg-rose-900/30 text-rose-300 border-rose-800",
  nationstate: "bg-blue-900/30 text-blue-300 border-blue-800",
  "nation-state": "bg-blue-900/30 text-blue-300 border-blue-800",
  apt: "bg-blue-900/30 text-blue-300 border-blue-800",
  ai: "bg-purple-900/30 text-purple-300 border-purple-800",
  tool: "bg-green-900/30 text-green-300 border-green-800",
  default: "bg-[#B87333]/20 text-[#B87333] border-[#B87333]/40",
};

export function CategoryBadge({ category, className = "" }: CategoryBadgeProps) {
  const key = category.toLowerCase().replace(/\s+/g, "");
  const colorClass = Object.entries(categoryColors).find(([k]) =>
    key.includes(k)
  )?.[1] ?? categoryColors.default;

  return (
    <span
      className={`inline-block text-[10px] uppercase tracking-wider font-bold px-2.5 py-1 rounded border ${colorClass} ${className}`}
    >
      {category}
    </span>
  );
}
