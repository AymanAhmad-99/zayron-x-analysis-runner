export function CopperDivider({ className = "" }: { className?: string }) {
  return <hr className={`copper-divider ${className}`} />;
}
