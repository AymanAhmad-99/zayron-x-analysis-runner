#!/bin/bash
# ============================================
# ZAYRON SECURITY — Deploy Script
# Run on VPS: bash deploy.sh
# ============================================

set -e

echo "=== ZAYRON SECURITY Deployment ==="
echo "Started: $(date)"

# Configuration
PROJECT_DIR="/var/www/zayron"
REPO_URL="https://github.com/zayronsec/zayron-security.git"
BRANCH="main"

# 1. Pull latest code
echo "--- Pulling latest code ---"
if [ -d "$PROJECT_DIR" ]; then
    cd "$PROJECT_DIR"
    git fetch origin "$BRANCH"
    git reset --hard "origin/$BRANCH"
else
    git clone --depth 1 --branch "$BRANCH" "$REPO_URL" "$PROJECT_DIR"
    cd "$PROJECT_DIR"
fi

# 2. Install dependencies
echo "--- Installing dependencies ---"
bun install --frozen-lockfile --production

# 3. Build
echo "--- Building Next.js ---"
bun run build

# 4. Apply database migrations (if any)
echo "--- Applying migrations ---"
bun run db:push || echo "Migration skipped — no pending changes"

# 5. Restart PM2 processes
echo "--- Restarting PM2 ---"
pm2 startOrReload "$PROJECT_DIR/pm2.ecosystem.config.js" --update-env

# 6. Reload Nginx
echo "--- Reloading Nginx ---"
sudo nginx -t && sudo systemctl reload nginx

# 7. Cleanup
echo "--- Cleaning up ---"
pm2 save

echo "=== Deployment complete: $(date) ==="
echo "Site: https://zayronsecurity.com"
