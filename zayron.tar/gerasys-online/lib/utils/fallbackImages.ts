const categoryImages: Record<string, string> = {
  ransomware: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80",
  malware: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?w=800&q=80",
  "nation-state": "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?w=800&q=80",
  apt: "https://images.unsplash.com/photo-1517430816045-df4b7de11d1d?w=800&q=80",
  vulnerability: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80",
  cve: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=800&q=80",
};

const DEFAULT_IMAGE = "https://images.unsplash.com/photo-1563206767-5b18f218e8de?w=800&q=80";

export function getArticleImage(article: { imageUrl?: string | null; category?: string | null }): string {
  if (article.imageUrl) return article.imageUrl;

  const cat = article.category?.toLowerCase().replace(/\s+/g, "-") ?? "";
  for (const [key, url] of Object.entries(categoryImages)) {
    if (cat.includes(key)) return url;
  }

  return DEFAULT_IMAGE;
}
