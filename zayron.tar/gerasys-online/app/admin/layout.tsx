import type { Metadata } from "next";
import Link from "next/link";
import {
  LayoutDashboard,
  FileText,
  ShieldAlert,
  Radio,
  Settings,
  ExternalLink,
  ChevronRight,
} from "lucide-react";

export const metadata: Metadata = {
  title: {
    default: "Admin — ZAYRON SECURITY",
    template: "%s — Admin | ZAYRON SECURITY",
  },
  robots: { index: false, follow: false },
};

const NAV_ITEMS = [
  { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "Intelligence", href: "/admin/articles", icon: FileText },
  { label: "CVE Monitor", href: "/admin/cves", icon: ShieldAlert },
  { label: "Raw Feeds", href: "/admin/feeds", icon: Radio },
  { label: "Settings", href: "/admin/settings", icon: Settings },
];

function Sidebar() {
  return (
    <aside className="w-64 shrink-0 bg-[#0D0D0D] border-r border-[#1a1a1a] min-h-screen flex flex-col">
      {/* Logo */}
      <div className="h-16 flex items-center px-6 border-b border-[#1a1a1a]">
        <Link href="/admin" className="flex items-baseline gap-1">
          <span className="font-display text-lg font-bold text-white tracking-tight">
            ZAYRON
          </span>
          <span className="text-copper font-display text-lg font-bold">.</span>
          <span className="text-[#6B6258] text-xs font-ui font-normal ml-1">
            Admin
          </span>
        </Link>
      </div>

      {/* Navigation */}
      <nav className="flex-1 py-4 px-3 space-y-1">
        {NAV_ITEMS.map((item) => {
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className="group flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-[#8C8074] hover:text-white hover:bg-[#1a1a1a] transition-all duration-200"
            >
              <Icon className="w-4 h-4 shrink-0 group-hover:text-copper transition-colors duration-200" />
              <span className="font-ui font-medium">{item.label}</span>
              <ChevronRight className="w-3 h-3 ml-auto opacity-0 group-hover:opacity-40 transition-all duration-200" />
            </Link>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-[#1a1a1a]">
        <Link
          href="/"
          className="flex items-center gap-2 text-xs text-[#6B6258] hover:text-copper transition-colors duration-200 font-ui"
        >
          <ExternalLink className="w-3 h-3" />
          View Public Site
        </Link>
      </div>
    </aside>
  );
}

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-[#0D0D0D] flex">
      <Sidebar />
      <main className="flex-1 bg-[#1a1a1a] min-h-screen overflow-auto">
        {children}
      </main>
    </div>
  );
}
