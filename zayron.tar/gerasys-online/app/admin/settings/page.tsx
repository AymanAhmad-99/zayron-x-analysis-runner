import type { Metadata } from "next";
import { Settings as SettingsIcon } from "lucide-react";

export const metadata: Metadata = {
  title: "Settings",
};

export default function AdminSettingsPage() {
  return (
    <div className="p-8 max-w-[1440px] mx-auto">
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-white tracking-tight">
          Settings
        </h1>
        <p className="text-sm text-[#6B6258] mt-1 font-ui">
          Site configuration and system preferences
        </p>
      </div>

      <div className="bg-[#0D0D0D] rounded-xl border border-[#2a2a2a] p-12 flex flex-col items-center justify-center text-center">
        <SettingsIcon className="w-10 h-10 text-[#2a2a2a] mb-4" />
        <p className="text-sm text-[#6B6258] font-ui max-w-md">
          Site configuration settings will be available in a future update.
          The settings panel will include API key management, feed source configuration,
          and system preferences.
        </p>
      </div>
    </div>
  );
}
