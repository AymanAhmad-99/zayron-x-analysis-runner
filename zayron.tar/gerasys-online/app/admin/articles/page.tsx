import type { Metadata } from "next";
import Link from "next/link";
import { formatDate } from "@/lib/utils/formatDate";

export const metadata: Metadata = {
  title: "Articles",
};

export const dynamic = "force-dynamic";

interface Props {
  searchParams: Promise<{ page?: string }>;
}

export default async function AdminArticlesPage({ searchParams }: Props) {
  const { page: pageStr } = await searchParams;
  const page = Number(pageStr) || 1;
  let articles: any[] = [];

  try {
    const { getAllArticlesAdmin } = await import("@/lib/db/queries/articles");
    articles = await getAllArticlesAdmin(page, 50);
  } catch {
    // DB not available
  }

  return (
    <div className="p-8 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-white tracking-tight">
            Intelligence
          </h1>
          <p className="text-sm text-[#6B6258] mt-1 font-ui">
            Published articles and intelligence reports
          </p>
        </div>
        <span className="text-xs font-ui font-medium text-[#6B6258] bg-[#0D0D0D] px-3 py-1.5 rounded-lg border border-[#2a2a2a]">
          {articles.length} articles
        </span>
      </div>

      <div className="bg-[#0D0D0D] rounded-xl border border-[#2a2a2a] overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2a2a2a]">
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest">
                Title
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden md:table-cell">
                Category
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden lg:table-cell">
                Status
              </th>
              <th className="text-right py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden lg:table-cell">
                Views
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden lg:table-cell">
                Date
              </th>
            </tr>
          </thead>
          <tbody>
            {articles.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-12 text-center text-sm text-[#6B6258] font-ui">
                  No articles yet. Intelligence reports will appear here once published.
                </td>
              </tr>
            ) : (
              articles.map((article, idx) => (
                <tr
                  key={article.id}
                  className="group border-b border-[#1a1a1a] last:border-0 hover:bg-white/[0.02] transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-mono text-[#6B6258] w-5 shrink-0">
                        {String(idx + 1).padStart(2, "0")}
                      </span>
                      <div>
                        <span className="text-sm text-white font-medium block max-w-xs truncate group-hover:text-copper transition-colors">
                          {article.title}
                        </span>
                        <span className="text-[10px] text-[#6B6258] font-ui">
                          {article.author}
                        </span>
                      </div>
                    </div>
                    {article.isFeatured && (
                      <span className="text-[9px] uppercase font-bold text-gold font-ui ml-8">
                        Featured
                      </span>
                    )}
                    {article.isBreaking && (
                      <span className="text-[9px] uppercase font-bold text-red-400 font-ui ml-2">
                        Breaking
                      </span>
                    )}
                  </td>
                  <td className="py-4 px-6 hidden md:table-cell">
                    <span className="text-[10px] font-ui font-semibold text-copper uppercase tracking-wider">
                      {article.category}
                    </span>
                  </td>
                  <td className="py-4 px-6 hidden lg:table-cell">
                    <span
                      className={`inline-flex items-center gap-1.5 text-[9px] font-ui font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                        article.isPublished
                          ? "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20"
                          : "text-amber-400 bg-amber-500/10 border border-amber-500/20"
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          article.isPublished ? "bg-emerald-400" : "bg-amber-400"
                        }`}
                      />
                      {article.isPublished ? "Published" : "Draft"}
                    </span>
                  </td>
                  <td className="py-4 px-6 text-right hidden lg:table-cell">
                    <span className="text-sm font-mono text-[#8C8074]">
                      {article.views?.toLocaleString() ?? 0}
                    </span>
                  </td>
                  <td className="py-4 px-6 hidden lg:table-cell">
                    <span className="text-xs font-mono text-[#6B6258]">
                      {article.createdAt ? formatDate(article.createdAt) : "—"}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {articles.length > 0 && (
        <div className="flex justify-center gap-3 mt-8">
          {page > 1 && (
            <Link
              href={`/admin/articles?page=${page - 1}`}
              className="px-4 py-2 text-xs font-ui font-medium text-[#8C8074] hover:text-white bg-[#0D0D0D] border border-[#2a2a2a] rounded-lg hover:border-copper/30 transition-all duration-200"
            >
              Previous
            </Link>
          )}
          <Link
            href={`/admin/articles?page=${page + 1}`}
            className="px-4 py-2 text-xs font-ui font-semibold text-white bg-copper border border-copper rounded-lg hover:bg-copper/80 transition-all duration-200"
          >
            Next
          </Link>
        </div>
      )}
    </div>
  );
}
