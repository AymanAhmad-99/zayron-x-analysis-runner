import type { Metadata } from "next";
import Link from "next/link";
import { SeverityBadge } from "@/components/cve/SeverityBadge";
import { formatDateShort } from "@/lib/utils/formatDate";

export const metadata: Metadata = {
  title: "CVEs",
};

export const dynamic = "force-dynamic";

interface Props {
  searchParams: Promise<{ page?: string }>;
}

export default async function AdminCVEsPage({ searchParams }: Props) {
  const { page: pageStr } = await searchParams;
  const page = Number(pageStr) || 1;
  let cves: any[] = [];
  let total = 0;

  try {
    const { getCVEs, getCVECount } = await import("@/lib/db/queries/cves");
    [cves, total] = await Promise.all([getCVEs(page, 50), getCVECount()]);
  } catch {
    // DB not available
  }

  return (
    <div className="p-8 max-w-[1440px] mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="font-display text-3xl font-bold text-white tracking-tight">
            CVE Monitor
          </h1>
          <p className="text-sm text-[#6B6258] mt-1 font-ui">
            Tracked vulnerabilities and severity distribution
          </p>
        </div>
        <span className="text-xs font-ui font-medium text-[#6B6258] bg-[#0D0D0D] px-3 py-1.5 rounded-lg border border-[#2a2a2a]">
          {total.toLocaleString()} total
        </span>
      </div>

      <div className="bg-[#0D0D0D] rounded-xl border border-[#2a2a2a] overflow-hidden">
        <table className="w-full">
          <thead>
            <tr className="border-b border-[#2a2a2a]">
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest">
                CVE ID
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest">
                Severity
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest">
                CVSS
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden md:table-cell">
                Product
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden md:table-cell">
                Status
              </th>
              <th className="text-left py-4 px-6 text-[10px] font-ui font-semibold text-[#6B6258] uppercase tracking-widest hidden lg:table-cell">
                Published
              </th>
            </tr>
          </thead>
          <tbody>
            {cves.length === 0 ? (
              <tr>
                <td colSpan={6} className="py-12 text-center text-sm text-[#6B6258] font-ui">
                  No CVEs tracked yet. The CVE ingestion pipeline will populate this table.
                </td>
              </tr>
            ) : (
              cves.map((cve, idx) => (
                <tr
                  key={cve.id}
                  className="group border-b border-[#1a1a1a] last:border-0 hover:bg-white/[0.02] transition-colors"
                >
                  <td className="py-4 px-6">
                    <div className="flex items-center gap-3">
                      <span className="text-[10px] font-mono text-[#6B6258] w-5 shrink-0">
                        {String(idx + 1).padStart(2, "0")}
                      </span>
                      <span className="text-sm font-mono font-semibold text-white group-hover:text-copper transition-colors">
                        {cve.cveId}
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-6">
                    <SeverityBadge severity={cve.severity} />
                  </td>
                  <td className="py-4 px-6 font-mono text-sm text-[#8C8074]">
                    {cve.cvssScore ?? "—"}
                  </td>
                  <td className="py-4 px-6 text-xs text-[#6B6258] hidden md:table-cell font-ui">
                    {cve.affectedProduct ?? "—"}
                  </td>
                  <td className="py-4 px-6 hidden md:table-cell">
                    <span
                      className={`inline-flex items-center gap-1.5 text-[9px] font-ui font-bold uppercase tracking-wider px-2.5 py-1 rounded-full ${
                        cve.status?.toLowerCase() === "active"
                          ? "text-red-400 bg-red-500/10 border border-red-500/20"
                          : "text-emerald-400 bg-emerald-500/10 border border-emerald-500/20"
                      }`}
                    >
                      <span
                        className={`w-1.5 h-1.5 rounded-full ${
                          cve.status?.toLowerCase() === "active" ? "bg-red-400" : "bg-emerald-400"
                        }`}
                      />
                      {cve.status ?? "Unknown"}
                    </span>
                  </td>
                  <td className="py-4 px-6 hidden lg:table-cell">
                    <span className="text-xs font-mono text-[#6B6258]">
                      {cve.publishedDate ? formatDateShort(cve.publishedDate) : "—"}
                    </span>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {cves.length > 0 && (
        <div className="flex justify-center gap-3 mt-8">
          {page > 1 && (
            <Link
              href={`/admin/cves?page=${page - 1}`}
              className="px-4 py-2 text-xs font-ui font-medium text-[#8C8074] hover:text-white bg-[#0D0D0D] border border-[#2a2a2a] rounded-lg hover:border-copper/30 transition-all duration-200"
            >
              Previous
            </Link>
          )}
          <Link
            href={`/admin/cves?page=${page + 1}`}
            className="px-4 py-2 text-xs font-ui font-semibold text-white bg-copper border border-copper rounded-lg hover:bg-copper/80 transition-all duration-200"
          >
            Next
          </Link>
        </div>
      )}
    </div>
  );
}
