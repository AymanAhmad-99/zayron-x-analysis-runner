import { NextResponse } from "next/server";
import { revalidatePath } from "next/cache";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const secret = request.headers.get("x-revalidate-secret");

    if (secret !== process.env.REVALIDATION_SECRET) {
      return NextResponse.json({ error: "Invalid secret" }, { status: 401 });
    }

    const { path, slug } = body;

    if (slug) {
      revalidatePath(`/article/${slug}`);
    }
    if (path) {
      revalidatePath(path);
    }

    // Always revalidate homepage
    revalidatePath("/");

    return NextResponse.json({
      success: true,
      revalidated: [path, slug ? `/article/${slug}` : null].filter(Boolean),
    });
  } catch (error) {
    console.error("API /revalidate error:", error);
    return NextResponse.json(
      { error: "Revalidation failed" },
      { status: 500 }
    );
  }
}
