import { NextResponse } from "next/server";
import { getCVEs, getCVECount, getCVEsBySeverity } from "@/lib/db/queries/cves";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Number(searchParams.get("page")) || 1;
    const limit = Number(searchParams.get("limit")) || 25;
    const severity = searchParams.get("severity");

    let cves;
    if (severity) {
      cves = await getCVEsBySeverity(severity, limit);
    } else {
      cves = await getCVEs(page, limit);
    }

    const total = await getCVECount();

    return NextResponse.json({
      cves,
      total,
      page,
      totalPages: Math.ceil(total / limit),
    });
  } catch (error) {
    console.error("API /cves error:", error);
    return NextResponse.json(
      { error: "Failed to fetch CVEs" },
      { status: 500 }
    );
  }
}
