import { NextResponse } from "next/server";
import { searchArticles } from "@/lib/db/queries/articles";
import { searchCVEs } from "@/lib/db/queries/cves";

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const query = searchParams.get("q")?.trim();
    const type = searchParams.get("type") ?? "all";

    if (!query) {
      return NextResponse.json(
        { error: "Query parameter 'q' is required" },
        { status: 400 }
      );
    }

    let articles: Awaited<ReturnType<typeof searchArticles>> = [];
    let cves: Awaited<ReturnType<typeof searchCVEs>> = [];

    if (type === "all" || type === "articles") {
      articles = await searchArticles(query);
    }
    if (type === "all" || type === "cves") {
      cves = await searchCVEs(query);
    }

    return NextResponse.json({ articles, cves, query });
  } catch (error) {
    console.error("API /search error:", error);
    return NextResponse.json(
      { error: "Search failed" },
      { status: 500 }
    );
  }
}
