import { NextResponse } from "next/server";
import { incrementArticleViews } from "@/lib/db/queries/articles";

export async function POST(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    await incrementArticleViews(id);
    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("API /views/[id] error:", error);
    return NextResponse.json(
      { error: "Failed to record view" },
      { status: 500 }
    );
  }
}
