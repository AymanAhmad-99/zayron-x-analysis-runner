import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ArticleHeader } from "@/components/article/ArticleHeader";
import { ArticleBody } from "@/components/article/ArticleBody";
import { ArticleSidebar } from "@/components/article/ArticleSidebar";
import { ReadingProgress } from "@/components/article/ReadingProgress";
import { ShareButtons } from "@/components/article/ShareButtons";
import { RelatedArticles } from "@/components/article/RelatedArticles";
import { AuthorCard } from "@/components/article/AuthorCard";
import { getArticleBySlug, getRelatedArticles, getTrendingArticles } from "@/lib/db/queries/articles";

const CATEGORY_IMAGES: Record<string, string> = {
  ransomware: "https://images.unsplash.com/photo-1614064647598-0fe6ae3ea118?w=1600&q=85",
  "nation-state": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600&q=85",
  "nation state": "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1600&q=85",
  intelligence: "https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=1600&q=85",
  vulnerabilities: "https://images.unsplash.com/photo-1555949963-aa79dcee981c?w=1600&q=85",
  "ai-security": "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1600&q=85",
  "ai security": "https://images.unsplash.com/photo-1677442136019-21780ecad995?w=1600&q=85",
  malware: "https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=1600&q=85",
  default: "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1600&q=85",
};

function getCategoryImage(category: string): string {
  const key = category.toLowerCase().replace(/\s+/g, "-");
  return CATEGORY_IMAGES[key] ?? "https://images.unsplash.com/photo-1555066931-4365d14bab8c?w=1600&q=85";
}

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  let article: Awaited<ReturnType<typeof getArticleBySlug>> = null;
  try {
    article = await getArticleBySlug(slug);
  } catch (error) {
    console.error(`generateMetadata failed for article "${slug}":`, error);
  }
  if (!article) return { title: "Article Not Found" };

  return {
    title: article.title,
    description: article.excerpt ?? article.content.substring(0, 160),
    openGraph: {
      title: article.title,
      description: article.excerpt ?? article.content.substring(0, 160),
      type: "article",
      publishedTime: article.createdAt?.toISOString(),
      authors: [article.author],
      images: article.imageUrl ? [{ url: article.imageUrl, width: 1200, height: 630 }] : [],
    },
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/article/${article.slug}`,
    },
  };
}

export const revalidate = 3600;

export default async function ArticlePage({ params }: Props) {
  const { slug } = await params;
  let article: Awaited<ReturnType<typeof getArticleBySlug>> = null;
  try {
    article = await getArticleBySlug(slug);
  } catch (error) {
    console.error(`ArticlePage data fetch failed for "${slug}":`, error);
  }
  if (!article) notFound();

  let relatedArticles: Awaited<ReturnType<typeof getRelatedArticles>> = [];
  let trendingArticles: Awaited<ReturnType<typeof getTrendingArticles>> = [];
  try {
    [relatedArticles, trendingArticles] = await Promise.all([
      getRelatedArticles(article.category, article.slug, 3),
      getTrendingArticles(5),
    ]);
  } catch (error) {
    console.error(`ArticlePage sidebar fetch failed for "${slug}":`, error);
  }

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "NewsArticle",
    headline: article.title,
    datePublished: article.createdAt?.toISOString(),
    dateModified: article.updatedAt?.toISOString(),
    author: { "@type": "Person", name: article.author },
    publisher: {
      "@type": "Organization",
      name: "ZAYRON SECURITY",
      url: process.env.NEXT_PUBLIC_SITE_URL,
    },
    description: article.excerpt ?? article.content.substring(0, 160),
    image: article.imageUrl,
  };

  return (
    <>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ReadingProgress />
      {/* Full-width hero image */}
      <div className="relative w-full h-[420px] lg:h-[520px] overflow-hidden bg-[var(--color-obsidian)]">
        <img
          src={article.imageUrl ?? getCategoryImage(article.category)}
          alt={article.title}
          className="absolute inset-0 w-full h-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-[var(--color-obsidian)] via-[var(--color-obsidian)]/40 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 max-w-7xl mx-auto px-4 pb-10">
          <div className="max-w-3xl">
            <ArticleHeader article={article} overlay />
          </div>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[68%_32%] gap-10">
          {/* Main */}
          <div>
            <ArticleBody content={article.content} />
            <ShareButtons
              url={`${process.env.NEXT_PUBLIC_SITE_URL}/article/${article.slug}`}
              title={article.title}
            />
            <AuthorCard name={article.author} />
            <RelatedArticles articles={relatedArticles} />
          </div>

          {/* Sidebar */}
          <div className="hidden lg:block">
            <div className="sticky top-24 space-y-8">
              <ArticleSidebar trending={trendingArticles} />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
