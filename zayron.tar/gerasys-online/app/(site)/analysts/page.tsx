import type { Metadata } from "next";
import { AnalystTeam } from "@/components/homepage/AnalystTeam";

export const metadata: Metadata = {
  title: "Threat Intelligence Analysts",
  description: "Meet the ZAYRON SECURITY threat intelligence analyst team.",
  alternates: {
    canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/analysts`,
  },
};

export default function AnalystsPage() {
  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="section-subheading">Our Team</h1>
        <h2 className="font-display text-3xl font-bold text-[var(--color-obsidian)] mt-1">
          Threat Intelligence Analysts
        </h2>
        <p className="text-sm text-[var(--color-stone)] mt-2 font-ui max-w-2xl">
          Our team of experienced cybersecurity professionals monitors global threat landscapes,
          analyzes emerging vulnerabilities, and delivers actionable intelligence.
        </p>
      </div>
      <AnalystTeam analysts={[]} />
    </div>
  );
}
