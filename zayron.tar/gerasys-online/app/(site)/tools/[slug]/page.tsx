import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getToolBySlug } from "@/lib/db/queries/tools";
import { Star, ExternalLink, GitFork } from "lucide-react";

interface Props {
  params: Promise<{ slug: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  let tool: Awaited<ReturnType<typeof getToolBySlug>> = null;
  try {
    tool = await getToolBySlug(slug);
  } catch (error) {
    console.error(`generateMetadata failed for tool "${slug}":`, error);
  }
  if (!tool) return { title: "Tool Not Found" };

  return {
    title: `${tool.name} — Tool Review`,
    description: tool.description ?? `${tool.name} security tool details and analysis.`,
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/tools/${tool.slug}`,
    },
  };
}

export default async function ToolDetailPage({ params }: Props) {
  const { slug } = await params;
  let tool: Awaited<ReturnType<typeof getToolBySlug>> = null;
  try {
    tool = await getToolBySlug(slug);
  } catch (error) {
    console.error(`ToolDetailPage data fetch failed for "${slug}":`, error);
  }
  if (!tool) notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="flex items-center gap-2 text-xs text-[var(--color-stone)] mb-6 font-ui">
        <a href="/" className="hover:text-[var(--color-copper)]">Home</a>
        <span>/</span>
        <a href="/tools" className="hover:text-[var(--color-copper)]">Tools</a>
        <span>/</span>
        <span className="text-[var(--color-obsidian)]">{tool.name}</span>
      </nav>

      <div className="bg-white border border-[var(--color-border)] rounded-xl p-6 lg:p-8">
        <div className="flex items-start justify-between mb-4">
          <div>
            <span className="text-[10px] uppercase font-bold text-[var(--color-copper)] tracking-wider font-ui">
              {tool.category}
            </span>
            <h1 className="font-display text-3xl font-bold text-[var(--color-obsidian)] mt-1">
              {tool.name}
            </h1>
          </div>
          {tool.rating && (
            <span className="flex items-center gap-1.5 text-sm bg-[var(--color-gold)]/10 text-[var(--color-gold)] font-bold px-3 py-1.5 rounded-lg">
              <Star size={14} fill="currentColor" />
              {tool.rating}
            </span>
          )}
        </div>

        <p className="text-[var(--color-stone)] font-body leading-relaxed mb-6">
          {tool.description}
        </p>

        <div className="flex flex-wrap gap-4 items-center pt-4 border-t border-[var(--color-border)]">
          {tool.stars !== null && (
            <span className="flex items-center gap-1.5 text-sm text-[var(--color-stone)] font-mono">
              <GitFork size={14} />
              {tool.stars?.toLocaleString()} stars
            </span>
          )}
          {tool.githubUrl && (
            <a
              href={tool.githubUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-1.5 text-sm text-[var(--color-copper)] hover:underline font-ui"
            >
              View on GitHub <ExternalLink size={12} />
            </a>
          )}
        </div>
      </div>
    </div>
  );
}
