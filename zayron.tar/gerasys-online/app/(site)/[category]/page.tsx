import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { ArticleCard } from "@/components/ui/ArticleCard";
import { getArticlesByCategory, getCategoriesWithCounts } from "@/lib/db/queries/articles";

interface Props {
  params: Promise<{ category: string }>;
  searchParams: Promise<{ page?: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  const label = category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  return {
    title: `${label} — Intelligence Reports`,
    description: `Latest ${label} cyber threat intelligence reports and analysis.`,
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/${category}`,
    },
  };
}

export const revalidate = 300;

export default async function CategoryPage({ params, searchParams }: Props) {
  const { category } = await params;
  const { page: pageStr } = await searchParams;
  const page = Number(pageStr) || 1;

  const displayCategory = category.replace(/-/g, " ").replace(/\b\w/g, (c) => c.toUpperCase());
  let articles: Awaited<ReturnType<typeof getArticlesByCategory>> = [];
  try {
    articles = await getArticlesByCategory(displayCategory, page, 12);
  } catch (error) {
    console.error(`CategoryPage data fetch failed for "${displayCategory}":`, error);
  }
  if (!articles.length && page === 1) notFound();

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <span className="section-subheading">Category</span>
        <h1 className="font-display text-3xl font-bold text-white mt-1">
          {displayCategory}
        </h1>
      </div>

      {articles.length === 0 ? (
        <div className="text-center py-16 text-[var(--color-stone)] font-ui">
          No articles found in this category.
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {articles.map((article) => (
            <ArticleCard key={article.id} article={article} />
          ))}
        </div>
      )}

      <div className="flex justify-center gap-2 mt-8">
        {page > 1 && (
          <a
            href={`/${category}?page=${page - 1}`}
            className="px-4 py-2 text-sm border border-[var(--color-border)] rounded-lg hover:border-[var(--color-copper)] transition-colors font-ui"
          >
            Previous
          </a>
        )}
        {articles.length === 12 && (
          <a
            href={`/${category}?page=${page + 1}`}
            className="px-4 py-2 text-sm bg-[var(--color-copper)] text-white rounded-lg hover:bg-[var(--color-obsidian)] transition-colors font-ui"
          >
            Next
          </a>
        )}
      </div>
    </div>
  );
}
