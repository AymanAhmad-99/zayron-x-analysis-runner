import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { CveDetailCard } from "@/components/cve/CveDetailCard";
import { getCVEById } from "@/lib/db/queries/cves";

interface Props {
  params: Promise<{ cveId: string }>;
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { cveId } = await params;
  let cve: Awaited<ReturnType<typeof getCVEById>> = null;
  try {
    cve = await getCVEById(cveId);
  } catch (error) {
    console.error(`generateMetadata failed for CVE "${cveId}":`, error);
  }
  if (!cve) return { title: "CVE Not Found" };

  return {
    title: `${cve.cveId} — ${cve.severity} severity, CVSS ${cve.cvssScore}`,
    description: cve.description ?? `${cve.cveId} vulnerability details and analysis.`,
    alternates: {
      canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/cve/${cve.cveId}`,
    },
  };
}

export default async function CVEDetailPage({ params }: Props) {
  const { cveId } = await params;
  let cve: Awaited<ReturnType<typeof getCVEById>> = null;
  try {
    cve = await getCVEById(cveId);
  } catch (error) {
    console.error(`CVEDetailPage data fetch failed for "${cveId}":`, error);
  }
  if (!cve) notFound();

  return (
    <div className="max-w-4xl mx-auto px-4 py-8">
      <nav className="flex items-center gap-2 text-xs text-[var(--color-stone)] mb-6 font-ui">
        <a href="/" className="hover:text-[var(--color-copper)]">Home</a>
        <span>/</span>
        <a href="/cve" className="hover:text-[var(--color-copper)]">CVEs</a>
        <span>/</span>
        <span className="text-[var(--color-obsidian)]">{cve.cveId}</span>
      </nav>
      <CveDetailCard cve={cve} />
    </div>
  );
}
