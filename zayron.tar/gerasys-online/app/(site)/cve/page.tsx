import type { Metadata } from "next";
import { CveTable } from "@/components/cve/CveTable";
import { getCVEs, getCVECount } from "@/lib/db/queries/cves";

export const metadata: Metadata = {
  title: "CVE Tracker",
  description: "Live Common Vulnerabilities and Exposures (CVE) database. Track, filter, and analyze security vulnerabilities.",
  alternates: {
    canonical: `${process.env.NEXT_PUBLIC_SITE_URL}/cve`,
  },
};

export const revalidate = 300;

interface Props {
  searchParams: Promise<{ page?: string; severity?: string }>;
}

export default async function CVEPage({ searchParams }: Props) {
  const { page: pageStr, severity: sev } = await searchParams;
  const page = Number(pageStr) || 1;
  let cves: Awaited<ReturnType<typeof getCVEs>> = [];
  let totalCount = 0;
  try {
    cves = await getCVEs(page, 25);
    totalCount = await getCVECount();
  } catch (error) {
    console.error("CVEPage data fetch failed:", error);
  }
  const totalPages = Math.ceil(totalCount / 25);

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="section-subheading">Vulnerability Database</h1>
        <h2 className="font-display text-3xl font-bold text-[var(--color-obsidian)] mt-1">
          CVE Tracker
        </h2>
        <p className="text-sm text-[var(--color-stone)] mt-2 font-ui">
          Tracking {totalCount.toLocaleString()} vulnerabilities in real-time.
        </p>
      </div>

      <CveTable cves={cves} />

      {/* Pagination */}
      <div className="flex justify-center gap-2 mt-8">
        {page > 1 && (
          <a
            href={`/cve?page=${page - 1}`}
            className="px-4 py-2 text-sm border border-[var(--color-border)] rounded-lg hover:border-[var(--color-copper)] transition-colors font-ui"
          >
            Previous
          </a>
        )}
        {page < totalPages && (
          <a
            href={`/cve?page=${page + 1}`}
            className="px-4 py-2 text-sm bg-[var(--color-copper)] text-white rounded-lg hover:bg-[var(--color-obsidian)] transition-colors font-ui"
          >
            Next
          </a>
        )}
      </div>
    </div>
  );
}
