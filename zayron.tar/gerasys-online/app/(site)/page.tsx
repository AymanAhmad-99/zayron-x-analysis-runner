import { HeroSection } from "@/components/homepage/HeroSection";
import { ArticleCard } from "@/components/ui/ArticleCard";
import { Newsletter } from "@/components/homepage/Newsletter";
import { getRecentArticles, getBreakingArticles } from "@/lib/db/queries/articles";
import type { Article } from "@/lib/db/schema";

export const revalidate = 60;

export default async function HomePage() {
  let recentArticles: Article[] = [];
  let breakingArticles: Article[] = [];

  try {
    const [recent, breaking] = await Promise.all([
      getRecentArticles(10),
      getBreakingArticles(5),
    ]);
    recentArticles = recent;
    breakingArticles = breaking;
  } catch (error) {
    console.error("HomePage data fetch failed:", error);
  }

  const heroArticle = breakingArticles[0] ?? recentArticles[0] ?? null;
  const gridArticles = recentArticles.filter((a) => a.id !== heroArticle?.id);

  return (
    <main className="bg-[#0D0D0D] min-h-screen">
      <HeroSection
        primary={heroArticle}
        secondary={recentArticles.slice(1, 4)}
      />

      {gridArticles.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 py-12">
          <div className="mb-8">
            <h2 className="font-mono text-[10px] uppercase tracking-[0.2em] font-bold text-[#B87333]">
              INTELLIGENCE REPORTS
            </h2>
            <h3 className="font-display text-2xl font-bold text-white mt-1">
              Latest Threat Intelligence
            </h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {gridArticles.map((article) => (
              <ArticleCard key={article.id} article={article} />
            ))}
          </div>
        </section>
      )}

      <Newsletter />
    </main>
  );
}
