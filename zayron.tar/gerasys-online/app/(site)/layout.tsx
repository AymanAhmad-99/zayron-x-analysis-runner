const SITE_NAME = "ZAYRON SECURITY";

export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
