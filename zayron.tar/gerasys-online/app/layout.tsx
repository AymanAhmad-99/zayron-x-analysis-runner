import type { Metadata } from "next";
import "@/styles/globals.css";
import { Header } from "@/components/layout/Header";
import { Footer } from "@/components/layout/Footer";

export const metadata: Metadata = {
  title: {
    default: "ZAYRON SECURITY — Cyber Threat Intelligence",
    template: "%s | ZAYRON SECURITY",
  },
  description:
    "Premium cyber threat intelligence platform. Real-time CVE tracking, APT analysis, and cybersecurity research.",
  metadataBase: new URL(process.env.NEXT_PUBLIC_SITE_URL ?? "https://zayronsecurity.com"),
  openGraph: {
    type: "website",
    locale: "en_US",
    siteName: "ZAYRON SECURITY",
  },
  twitter: {
    card: "summary_large_image",
    site: "@zayronsec",
  },
  robots: {
    index: true,
    follow: true,
    "max-snippet": -1,
    "max-image-preview": "large",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@400;500;600;700&family=JetBrains+Mono:wght@400;500;700&family=Source+Serif+4:ital,wght@0,400;0,600;1,400&display=swap"
          rel="stylesheet"
        />
        <link rel="icon" type="image/svg+xml" href="/logo.svg" />
      </head>
      <body className="min-h-screen bg-[var(--color-warm-white)] text-[var(--color-charcoal)] antialiased">
        <Header />
        <main>{children}</main>
        <Footer />
      </body>
    </html>
  );
}
