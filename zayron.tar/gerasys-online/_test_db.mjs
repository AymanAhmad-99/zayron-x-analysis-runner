import postgres from "postgres";

const urls = [
  // Pooler with @ format
  "postgresql://drizzle_user@xdfndojvqazffcjngglr:zayron2026DB@aws-0-us-west-1.pooler.supabase.com:6543/postgres",
  // Pooler with . format (postgres user pattern but with custom user)
  "postgresql://drizzle_user:zayron2026DB@aws-0-us-west-1.pooler.supabase.com:6543/postgres?pgbouncer=true",
  // Direct connection
  "postgresql://drizzle_user:zayron2026DB@db.xdfndojvqazffcjngglr.supabase.co:5432/postgres",
];

for (const url of urls) {
  console.log("Trying:", url.split("@")[1].split(",")[0]);
  const sql = postgres(url, { prepare: false, connect_timeout: 10 });
  try {
    const [result] = await sql`SELECT 1 AS ok`;
    console.log("  CONNECTED:", result);
    await sql.end();
    process.exit(0);
  } catch (e) {
    console.log("  FAILED:", e.message);
    await sql.end().catch(() => {});
  }
}
process.exit(1);
